---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
  Abram ada iman (Faith) ^QfJpdL1Z

Sarai yg mandul bisa punya Anak ^yW976ExE

Gen 16:1-5 ^ZTYTxGfV

Abram X ada Iman (Faith) ^E1eM6E5Y

Abram menyetujui saran Sarai utk 
mengambil hambanya Sarai yaitu Hagar
utk jadi istrinya (Abram) utk bisa 
melahirkan keturunan & utk bisa
menggenapi Firman Tuhan (Covenant) ^NVJv9ybM

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"type": "rectangle",
			"version": 800,
			"versionNonce": 471051231,
			"isDeleted": false,
			"id": "2DNAcRnP58S5ow-TuP1JW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -535.1383705726037,
			"y": -324.59998614971454,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 801.6000671386719,
			"height": 298.2545249245384,
			"seed": 1142997183,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 543,
			"versionNonce": 557106577,
			"isDeleted": false,
			"id": "lX6ShvEqZVTlFn1MFN8cp",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -149.10762528639566,
			"y": -326.44622685359076,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 3.9860545338450493,
			"height": 299.39580701281136,
			"seed": 909351569,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					3.9860545338450493,
					299.39580701281136
				]
			]
		},
		{
			"type": "line",
			"version": 350,
			"versionNonce": 1301338111,
			"isDeleted": false,
			"id": "BllYZeUzzmLa-RttxXy_S",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -539.938510953463,
			"y": -235.80001361553482,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 802.8001098632812,
			"height": 4.79998779296875,
			"seed": 755967263,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					802.8001098632812,
					4.79998779296875
				]
			]
		},
		{
			"type": "text",
			"version": 470,
			"versionNonce": 847768433,
			"isDeleted": false,
			"id": "QfJpdL1Z",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -525.5384865394005,
			"y": -296.09090023440916,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 353,
			"height": 36,
			"seed": 1876705169,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "RR3o-pqylKb_AftMsJGT2",
					"type": "arrow"
				}
			],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "  Abram ada iman (Faith)",
			"rawText": "  Abram ada iman (Faith)",
			"baseline": 25,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "  Abram ada iman (Faith)"
		},
		{
			"type": "arrow",
			"version": 1164,
			"versionNonce": 336226673,
			"isDeleted": false,
			"id": "RR3o-pqylKb_AftMsJGT2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -508.5594271005457,
			"y": -248.89090328616697,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 31.199981689453125,
			"height": 60.02823913810079,
			"seed": 1556741489,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1665801457293,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "QfJpdL1Z",
				"focus": 0.734383413362785,
				"gap": 11.199996948242188
			},
			"endBinding": {
				"elementId": "yW976ExE",
				"focus": -0.4394223456141178,
				"gap": 3.6002197265627274
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-19.3791143704957,
					27.490914084694623
				],
				[
					-19.379083852917574,
					57.49089882590556
				],
				[
					11.820867318957426,
					60.02823913810079
				]
			]
		},
		{
			"type": "text",
			"version": 306,
			"versionNonce": 902571071,
			"isDeleted": false,
			"id": "yW976ExE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -493.13834005502554,
			"y": -199.20002277080826,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 323,
			"height": 25,
			"seed": 1672066655,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "RR3o-pqylKb_AftMsJGT2",
					"type": "arrow"
				}
			],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Sarai yg mandul bisa punya Anak",
			"rawText": "Sarai yg mandul bisa punya Anak",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Sarai yg mandul bisa punya Anak"
		},
		{
			"type": "line",
			"version": 1565,
			"versionNonce": 509297759,
			"isDeleted": false,
			"id": "eD1oo4bW_RQiFN4I9McJd",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.305891026715994,
			"x": 218.961880410341,
			"y": -320.2146661370121,
			"strokeColor": "#000000",
			"backgroundColor": "#fa5252",
			"width": 121.2000732421875,
			"height": 258.00001525878906,
			"seed": 1375626161,
			"groupIds": [
				"DZCcsUfjw9zLC-oF5BYDp",
				"UHuh8dFQ6k3nnm4sQX2qV",
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					42,
					205.1999969482422
				],
				[
					66,
					248.3999481201172
				],
				[
					84.0001220703125,
					207.59999084472656
				],
				[
					106.800048828125,
					250.8000030517578
				],
				[
					121.2000732421875,
					206.40000915527344
				],
				[
					74.4000244140625,
					-7.20001220703125
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "rectangle",
			"version": 940,
			"versionNonce": 2066806033,
			"isDeleted": false,
			"id": "Om2diBh5ucRTyVzU6MoUP",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.170361189156033,
			"x": 225.21820626955855,
			"y": -326.73853705368657,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 70.39978469496123,
			"height": 11.851817827043417,
			"seed": 2010609279,
			"groupIds": [
				"DZCcsUfjw9zLC-oF5BYDp",
				"UHuh8dFQ6k3nnm4sQX2qV",
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1652,
			"versionNonce": 1146183807,
			"isDeleted": false,
			"id": "ZTYTxGfV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 1.3941405970680831,
			"x": 182.7897419061444,
			"y": -233.7853943405427,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 194,
			"height": 52,
			"seed": 606640287,
			"groupIds": [
				"UHuh8dFQ6k3nnm4sQX2qV",
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"fontSize": 40.7008884810586,
			"fontFamily": 1,
			"text": "Gen 16:1-5",
			"rawText": "Gen 16:1-5",
			"baseline": 36,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Gen 16:1-5"
		},
		{
			"type": "text",
			"version": 320,
			"versionNonce": 1817324273,
			"isDeleted": false,
			"id": "E1eM6E5Y",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -139.1385231604943,
			"y": -297.1000319260817,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 365,
			"height": 36,
			"seed": 1286122815,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Abram X ada Iman (Faith)",
			"rawText": "Abram X ada Iman (Faith)",
			"baseline": 25,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Abram X ada Iman (Faith)"
		},
		{
			"type": "text",
			"version": 533,
			"versionNonce": 1555338015,
			"isDeleted": false,
			"id": "NVJv9ybM",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -132.0475474857784,
			"y": -197.3454418048992,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 378,
			"height": 126,
			"seed": 2045860593,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801471789,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Abram menyetujui saran Sarai utk \nmengambil hambanya Sarai yaitu Hagar\nutk jadi istrinya (Abram) utk bisa \nmelahirkan keturunan & utk bisa\nmenggenapi Firman Tuhan (Covenant)",
			"rawText": "Abram menyetujui saran Sarai utk \nmengambil hambanya Sarai yaitu Hagar\nutk jadi istrinya (Abram) utk bisa \nmelahirkan keturunan & utk bisa\nmenggenapi Firman Tuhan (Covenant)",
			"baseline": 119,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Abram menyetujui saran Sarai utk \nmengambil hambanya Sarai yaitu Hagar\nutk jadi istrinya (Abram) utk bisa \nmelahirkan keturunan & utk bisa\nmenggenapi Firman Tuhan (Covenant)"
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 1938924753,
			"isDeleted": false,
			"id": "lO6bL-L3szORUx_DAECi6",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -158.1901393937717,
			"y": -315.56572641686427,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 113632799,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 56921279,
			"isDeleted": false,
			"id": "_C8jgGq47YCnyh5PNCxJQ",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -154.49781761642805,
			"y": -298.18111807476686,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 1487887135,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 1015472817,
			"isDeleted": false,
			"id": "HvnfXUA_k0filw_YsVXI0",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -156.80550992412032,
			"y": -282.79650269015144,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 1356769873,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 1574083807,
			"isDeleted": false,
			"id": "pW5KhtqazitFCuRvBVm4L",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -158.34397146258186,
			"y": -265.8734257670746,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 829726527,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 333014161,
			"isDeleted": false,
			"id": "R4z4TtXXuNo4oCjpE02I6",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -159.11320223181258,
			"y": -251.25804115168995,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 624713567,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 1011460351,
			"isDeleted": false,
			"id": "2NQlQ5lpDI7yTXISI4nC5",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -156.80550992412032,
			"y": -227.4118873055361,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 583207441,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 1161865841,
			"isDeleted": false,
			"id": "npoh_6o-usetShACBO9Gk",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -156.80550992412032,
			"y": -217.4118873055361,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 643242879,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 743059743,
			"isDeleted": false,
			"id": "n-DJseHNERg1K7Ou-tk1W",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -158.34397146258186,
			"y": -205.87342576707456,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 1658429425,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 964965457,
			"isDeleted": false,
			"id": "VAJH87NIDw23NfYHtmIqw",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -157.57474069335103,
			"y": -194.33496422861302,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 151344031,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 927249727,
			"isDeleted": false,
			"id": "pKUVx9gpP6PTBYyRsXv8c",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -157.57474069335103,
			"y": -187.4118873055361,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 1935833553,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 1417380401,
			"isDeleted": false,
			"id": "izv7QN-aYZE-ZX_RDG6i1",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -157.57474069335103,
			"y": -174.33496422861302,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 1165461439,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 1687795039,
			"isDeleted": false,
			"id": "glHswJQcnHmPDDLwl_sgY",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -156.0362791548896,
			"y": -165.10419499784385,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 359995313,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 319689745,
			"isDeleted": false,
			"id": "C7ySw_bunqQqrk2GYMEN8",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -158.34397146258186,
			"y": -150.4888103824592,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 2043557855,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 2073670015,
			"isDeleted": false,
			"id": "dpY9kfOLSXiwmBvYjfCxh",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -158.34397146258186,
			"y": -137.41188730553608,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 2067331473,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 1764977137,
			"isDeleted": false,
			"id": "PnZzttD8vRY58Ex3VR6Ax",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -158.34397146258186,
			"y": -122.7965026901515,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 739894271,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 92613023,
			"isDeleted": false,
			"id": "2dheTBJ4Rc0UwvjdeXzY4",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -156.80550992412032,
			"y": -108.95034884399763,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 635805553,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 1609761745,
			"isDeleted": false,
			"id": "Sq5cxmRplnU77fNLFhk-G",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -159.11320223181258,
			"y": -93.56573345938227,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 1281035295,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 260873663,
			"isDeleted": false,
			"id": "8Im9pUfBoPTkkK5YdbQPa",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -158.34397146258186,
			"y": -76.64265653630531,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 63080785,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 1935958449,
			"isDeleted": false,
			"id": "NTRS-krxoLNBAwuK-BJdg",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -157.57474069335103,
			"y": -66.64265653630531,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 1988243519,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 751865311,
			"isDeleted": false,
			"id": "lBOqH_mQWfdZdqQg9GlDF",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -157.57474069335103,
			"y": -48.95034884399763,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 1311192881,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 132,
			"versionNonce": 816776081,
			"isDeleted": false,
			"id": "h5_ut92bCBdDIhnClhuIt",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -158.34397146258186,
			"y": -38.95034884399763,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 1953484895,
			"groupIds": [
				"C4pTT3_6uJlqESNwXFmai"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801457292,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "#868e96",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 28,
		"currentItemTextAlign": "left",
		"currentItemStrokeSharpness": "round",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"currentItemLinearStrokeSharpness": "sharp",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%