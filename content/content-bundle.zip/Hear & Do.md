---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Rock ^wR3DUjyW

Sand ^Idi7Ilwn

Truth ^GUFekbuC

X Truth ^TCK0TbQL

Fell Great ^k4csiSPv

Fell Not ^oF3e0j1u

Foolish ^I9ohWPsd

Wise ^RRQnAMjm

The Church of Living God ^guHK4dYx

The Church of Babylon the Great ^PW9iwtmd

Head -> Christ ^aR44HW80

Head -> X Christ ^hCGUMSfX

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"type": "rectangle",
			"version": 1124,
			"versionNonce": 900560948,
			"isDeleted": false,
			"id": "saRvLM3FT94e4a8dnZjVy",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 211.77343292887136,
			"y": 28.012196647454786,
			"strokeColor": "#000000",
			"backgroundColor": "brown",
			"width": 86.5950814224945,
			"height": 71.76097167343394,
			"seed": 1079635764,
			"groupIds": [
				"BLUMEG_Y-flE-gXNFgJNg",
				"FmQcYFwuoNmT7zFszXx18",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 3074,
			"versionNonce": 1613518092,
			"isDeleted": false,
			"id": "C3s9YH70JmiOm5SS-Wyco",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0.004914067637287189,
			"x": 242.4146532714712,
			"y": -5.609057897203712,
			"strokeColor": "#000000",
			"backgroundColor": "brown",
			"width": 108.303246414319,
			"height": 43.6180315562432,
			"seed": 1362505268,
			"groupIds": [
				"6svtEUgvRvdBDy2P8sJ3N",
				"BLUMEG_Y-flE-gXNFgJNg",
				"FmQcYFwuoNmT7zFszXx18",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					31.160260290519105,
					0.06530133132146063
				],
				[
					65.7497884083448,
					43.6180315562432
				],
				[
					-42.5534580059742,
					43.61178767646097
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 1130,
			"versionNonce": 1194873268,
			"isDeleted": false,
			"id": "9Q5i_IuNcbYQFVgwgnYl7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 242.75576159993585,
			"y": -4.9144086686766855,
			"strokeColor": "#000000",
			"backgroundColor": "brown",
			"width": 0,
			"height": 42.974410625146696,
			"seed": 657587980,
			"groupIds": [
				"6svtEUgvRvdBDy2P8sJ3N",
				"BLUMEG_Y-flE-gXNFgJNg",
				"FmQcYFwuoNmT7zFszXx18",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0,
					42.974410625146696
				]
			]
		},
		{
			"type": "line",
			"version": 1030,
			"versionNonce": 611701644,
			"isDeleted": false,
			"id": "UNcD1-maU79DHaR4wtoBP",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 273.25593123296153,
			"y": -6.223518447797169,
			"strokeColor": "#000000",
			"backgroundColor": "brown",
			"width": 0,
			"height": 45.236221710680745,
			"seed": 473581492,
			"groupIds": [
				"6svtEUgvRvdBDy2P8sJ3N",
				"BLUMEG_Y-flE-gXNFgJNg",
				"FmQcYFwuoNmT7zFszXx18",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0,
					45.236221710680745
				]
			]
		},
		{
			"type": "line",
			"version": 1142,
			"versionNonce": 1697381172,
			"isDeleted": false,
			"id": "yzEAiXg_xtpAPKRqLdZfx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 233.64161231644692,
			"y": 10.186593917789473,
			"strokeColor": "#000000",
			"backgroundColor": "brown",
			"width": 54.28346605281686,
			"height": 0,
			"seed": 288767372,
			"groupIds": [
				"6svtEUgvRvdBDy2P8sJ3N",
				"BLUMEG_Y-flE-gXNFgJNg",
				"FmQcYFwuoNmT7zFszXx18",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					54.28346605281686,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 1136,
			"versionNonce": 1342931468,
			"isDeleted": false,
			"id": "bCCFZ9v0SuIhSkzAxKLPw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 215.57974855184372,
			"y": 26.60171170164645,
			"strokeColor": "#000000",
			"backgroundColor": "brown",
			"width": 81.42519907922532,
			"height": 2.261811085534037,
			"seed": 1920938292,
			"groupIds": [
				"6svtEUgvRvdBDy2P8sJ3N",
				"BLUMEG_Y-flE-gXNFgJNg",
				"FmQcYFwuoNmT7zFszXx18",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					81.42519907922532,
					-2.261811085534037
				]
			]
		},
		{
			"type": "rectangle",
			"version": 863,
			"versionNonce": 703493300,
			"isDeleted": false,
			"id": "ICEDMxS0XNE2axvBopTG2",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 242.0597403332033,
			"y": 65.03997447069123,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 27.1958678732777,
			"height": 29.725716047536068,
			"seed": 758785588,
			"groupIds": [
				"5G5V1ao9w2W_W9SuL_VaZ",
				"BLUMEG_Y-flE-gXNFgJNg",
				"FmQcYFwuoNmT7zFszXx18",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false
		},
		{
			"type": "freedraw",
			"version": 699,
			"versionNonce": 166158476,
			"isDeleted": false,
			"id": "ko8mvLtVDsVkZcbalc7oo",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 265.46083594509355,
			"y": 81.85152555980616,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 0,
			"height": 0.6324620435645978,
			"seed": 1316593204,
			"groupIds": [
				"5G5V1ao9w2W_W9SuL_VaZ",
				"BLUMEG_Y-flE-gXNFgJNg",
				"FmQcYFwuoNmT7zFszXx18",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					-0.36753795643540216
				],
				[
					0,
					-1
				],
				[
					0,
					-0.36753795643540216
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.140625,
				0.435546875,
				0
			]
		},
		{
			"type": "rectangle",
			"version": 749,
			"versionNonce": 1931853364,
			"isDeleted": false,
			"id": "jtQDDzSiEtraV9gXmJP5D",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 219.639012738273,
			"y": 41.05917315228342,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 20.331366830871378,
			"height": 19.099162780515528,
			"seed": 588590260,
			"groupIds": [
				"aZ9Mqp5eeMcPo7t1f-8Pa",
				"BLUMEG_Y-flE-gXNFgJNg",
				"FmQcYFwuoNmT7zFszXx18",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 782,
			"versionNonce": 163802892,
			"isDeleted": false,
			"id": "O39cwHIY5142_mWoxLlRA",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 232.04663266152738,
			"y": 41.780414649309975,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 0.17624932134511298,
			"height": 18.49180545881983,
			"seed": 682965428,
			"groupIds": [
				"aZ9Mqp5eeMcPo7t1f-8Pa",
				"BLUMEG_Y-flE-gXNFgJNg",
				"FmQcYFwuoNmT7zFszXx18",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.17624932134511298,
					18.49180545881983
				]
			]
		},
		{
			"type": "line",
			"version": 766,
			"versionNonce": 2042091444,
			"isDeleted": false,
			"id": "aAGrj9q_OFObC_ERSXp4R",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 220.01744810752893,
			"y": 50.73154215435807,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 20.653827096797272,
			"height": 0.5231419833392068,
			"seed": 2024809740,
			"groupIds": [
				"aZ9Mqp5eeMcPo7t1f-8Pa",
				"BLUMEG_Y-flE-gXNFgJNg",
				"FmQcYFwuoNmT7zFszXx18",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					20.653827096797272,
					0.5231419833392068
				]
			]
		},
		{
			"type": "rectangle",
			"version": 782,
			"versionNonce": 1682828,
			"isDeleted": false,
			"id": "Yftrgf1J2TIw3FlhxHM5T",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 274.9141987338949,
			"y": 43.65069611220754,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 20.331366830871378,
			"height": 19.099162780515528,
			"seed": 61154484,
			"groupIds": [
				"PwAX4FlOPIbH1O4bu-PqZ",
				"BLUMEG_Y-flE-gXNFgJNg",
				"FmQcYFwuoNmT7zFszXx18",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 815,
			"versionNonce": 1774895412,
			"isDeleted": false,
			"id": "ExacB8wGaFc6yC56IvX58",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 286.5562873418872,
			"y": 43.91163110541601,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 0.17624932134511298,
			"height": 18.49180545881983,
			"seed": 1345564812,
			"groupIds": [
				"PwAX4FlOPIbH1O4bu-PqZ",
				"BLUMEG_Y-flE-gXNFgJNg",
				"FmQcYFwuoNmT7zFszXx18",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.17624932134511298,
					18.49180545881983
				]
			]
		},
		{
			"type": "line",
			"version": 799,
			"versionNonce": 2116295692,
			"isDeleted": false,
			"id": "2MovxoiKaOjY_2yB0IY9Y",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 275.68939835292525,
			"y": 53.225468976157174,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 20.653827096797272,
			"height": 0.5231419833392068,
			"seed": 1116106292,
			"groupIds": [
				"PwAX4FlOPIbH1O4bu-PqZ",
				"BLUMEG_Y-flE-gXNFgJNg",
				"FmQcYFwuoNmT7zFszXx18",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					20.653827096797272,
					0.5231419833392068
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1602,
			"versionNonce": 2059696820,
			"isDeleted": false,
			"id": "wdZnBi0rCQOCgkVuNavJk",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 78.23505791083903,
			"y": 99.06091858521607,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"width": 343.1015625,
			"height": 84.12272979765108,
			"seed": 584782260,
			"groupIds": [
				"FmQcYFwuoNmT7zFszXx18",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 243,
			"versionNonce": 1574746764,
			"isDeleted": false,
			"id": "wR3DUjyW",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 172.13199300699284,
			"y": 131.32090132090133,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"width": 60,
			"height": 33,
			"seed": 595968948,
			"groupIds": [
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"fontSize": 26.495726495726505,
			"fontFamily": 1,
			"text": "Rock",
			"rawText": "Rock",
			"baseline": 23,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Rock"
		},
		{
			"type": "line",
			"version": 257,
			"versionNonce": 122356788,
			"isDeleted": false,
			"id": "bGYka-SUCxaRKRmC5LgM3",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 237.24670318369897,
			"y": 149.77333615932255,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"width": 27.69230769230768,
			"height": 1.5384615384615188,
			"seed": 2034271116,
			"groupIds": [
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					27.69230769230768,
					1.5384615384615188
				]
			]
		},
		{
			"type": "text",
			"version": 254,
			"versionNonce": 704481548,
			"isDeleted": false,
			"id": "GUFekbuC",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 272.6313185683145,
			"y": 133.0810284670148,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"width": 72,
			"height": 31,
			"seed": 1814907276,
			"groupIds": [
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"fontSize": 24.923076923076913,
			"fontFamily": 1,
			"text": "Truth",
			"rawText": "Truth",
			"baseline": 22,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Truth"
		},
		{
			"type": "text",
			"version": 377,
			"versionNonce": 625237428,
			"isDeleted": false,
			"id": "oF3e0j1u",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 126.47747241446882,
			"y": -11.53435614836988,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"width": 79,
			"height": 25,
			"seed": 1768533556,
			"groupIds": [
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Fell Not",
			"rawText": "Fell Not",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Fell Not"
		},
		{
			"type": "ellipse",
			"version": 2054,
			"versionNonce": 100697996,
			"isDeleted": false,
			"id": "iorEgTP3LV9XJUWsYliu5",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.257607789135728,
			"x": 312.7970729734602,
			"y": 67.50299402736029,
			"strokeColor": "#000000",
			"backgroundColor": "beige",
			"width": 9.108842691974834,
			"height": 9.189781281566365,
			"seed": 1661566092,
			"groupIds": [
				"zjcNPouStPvWlUtg5bGE4",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 2034,
			"versionNonce": 1037469492,
			"isDeleted": false,
			"id": "zdr2G0HnuprLP47HpzybR",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.257607789135728,
			"x": 318.605849800285,
			"y": 76.75454133326399,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0.24506083417510272,
			"height": 12.743163377105395,
			"seed": 1237541428,
			"groupIds": [
				"zjcNPouStPvWlUtg5bGE4",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.24506083417510272,
					12.743163377105395
				]
			]
		},
		{
			"type": "line",
			"version": 2012,
			"versionNonce": 371176972,
			"isDeleted": false,
			"id": "hXGM6TbymxFGSOvX-qAGs",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.257607789135728,
			"x": 318.59337629590743,
			"y": 88.27489018817283,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 1.5928954221381744,
			"height": 8.087007527778418,
			"seed": 809634572,
			"groupIds": [
				"zjcNPouStPvWlUtg5bGE4",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.5928954221381744,
					8.087007527778418
				]
			]
		},
		{
			"type": "line",
			"version": 2019,
			"versionNonce": 627540148,
			"isDeleted": false,
			"id": "dnARiH_4UudxtbHoapSA8",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.257607789135728,
			"x": 318.4645871844431,
			"y": 88.831804609835,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 1.837956256313273,
			"height": 8.087007527778418,
			"seed": 1962998708,
			"groupIds": [
				"zjcNPouStPvWlUtg5bGE4",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.837956256313273,
					8.087007527778418
				]
			]
		},
		{
			"type": "line",
			"version": 2204,
			"versionNonce": 1733629068,
			"isDeleted": false,
			"id": "q8g5hz3Gh6CQ10mcLuzbh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.257607789135728,
			"x": 318.71545160558475,
			"y": 80.89797061596886,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 3.174228095778431,
			"height": 6.964582364634677,
			"seed": 342149516,
			"groupIds": [
				"zjcNPouStPvWlUtg5bGE4",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					3.174228095778431,
					6.964582364634677
				]
			]
		},
		{
			"type": "line",
			"version": 2146,
			"versionNonce": 865946164,
			"isDeleted": false,
			"id": "oQuH1rCLimnDANxjgU0oQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.257607789135728,
			"x": 316.69609728902736,
			"y": 81.05731472041715,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 5.603746909572575,
			"height": 6.147186124043069,
			"seed": 1750033716,
			"groupIds": [
				"zjcNPouStPvWlUtg5bGE4",
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-5.603746909572575,
					-6.147186124043069
				]
			]
		},
		{
			"type": "text",
			"version": 237,
			"versionNonce": 1465557772,
			"isDeleted": false,
			"id": "RRQnAMjm",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 319.5543954913931,
			"y": 46.92718231316847,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"width": 42,
			"height": 25,
			"seed": 335532940,
			"groupIds": [
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Wise",
			"rawText": "Wise",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Wise"
		},
		{
			"type": "text",
			"version": 459,
			"versionNonce": 1532879796,
			"isDeleted": false,
			"id": "guHK4dYx",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 122.49145842845621,
			"y": -156.91897153298532,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"width": 250,
			"height": 25,
			"seed": 2065267252,
			"groupIds": [
				"nlCdFHZNpgbvTJL_KbY18"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243175133,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "The Church of Living God",
			"rawText": "The Church of Living God",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "The Church of Living God"
		},
		{
			"type": "rectangle",
			"version": 1490,
			"versionNonce": 776365196,
			"isDeleted": false,
			"id": "CzX6SznwBNqriRJ4W3oTZ",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -192.66499158277765,
			"y": 35.72456367709098,
			"strokeColor": "#000000",
			"backgroundColor": "brown",
			"width": 84.47778548986334,
			"height": 70.00637763702996,
			"seed": 1643223308,
			"groupIds": [
				"63ne4JnFaBkJG6f9wx0Ty",
				"V8W2XckbDyZllfYeTaSWo",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 3440,
			"versionNonce": 187234868,
			"isDeleted": false,
			"id": "JCXV222XaUNZA9iXz4htZ",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0.004914067637287189,
			"x": -162.87976256518917,
			"y": 2.3797720521532284,
			"strokeColor": "#000000",
			"backgroundColor": "brown",
			"width": 105.65517426799246,
			"height": 42.55154741781008,
			"seed": 576277940,
			"groupIds": [
				"G3qkxMnpIZSGXCk8PY7HM",
				"63ne4JnFaBkJG6f9wx0Ty",
				"V8W2XckbDyZllfYeTaSWo",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					30.398375304800936,
					0.06370467893738632
				],
				[
					64.14217100927873,
					42.55154741781008
				],
				[
					-41.513003258713724,
					42.545456204219136
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 1496,
			"versionNonce": 1403122444,
			"isDeleted": false,
			"id": "kGAuezf_mMmlrpHMLjZHr",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -161.8018319828445,
			"y": 3.4116984441358227,
			"strokeColor": "#000000",
			"backgroundColor": "brown",
			"width": 0,
			"height": 41.923663361801474,
			"seed": 1156749196,
			"groupIds": [
				"G3qkxMnpIZSGXCk8PY7HM",
				"63ne4JnFaBkJG6f9wx0Ty",
				"V8W2XckbDyZllfYeTaSWo",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0,
					41.923663361801474
				]
			]
		},
		{
			"type": "line",
			"version": 1396,
			"versionNonce": 636720052,
			"isDeleted": false,
			"id": "GrGjfqlTNk6eBGDMWZu1a",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -132.33505942120945,
			"y": 2.214915220863446,
			"strokeColor": "#000000",
			"backgroundColor": "brown",
			"width": 0,
			"height": 44.13017195979097,
			"seed": 718108468,
			"groupIds": [
				"G3qkxMnpIZSGXCk8PY7HM",
				"63ne4JnFaBkJG6f9wx0Ty",
				"V8W2XckbDyZllfYeTaSWo",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0,
					44.13017195979097
				]
			]
		},
		{
			"type": "line",
			"version": 1508,
			"versionNonce": 327659916,
			"isDeleted": false,
			"id": "3aVj3TCERmfePLZEgK62T",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -171.45682082394967,
			"y": 18.623632204108787,
			"strokeColor": "#000000",
			"backgroundColor": "brown",
			"width": 52.95620635174916,
			"height": 0,
			"seed": 1280296460,
			"groupIds": [
				"G3qkxMnpIZSGXCk8PY7HM",
				"63ne4JnFaBkJG6f9wx0Ty",
				"V8W2XckbDyZllfYeTaSWo",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					52.95620635174916,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 1502,
			"versionNonce": 254737716,
			"isDeleted": false,
			"id": "IkZOaAcIIYXjSz-3bVOip",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -189.05255690758287,
			"y": 34.23755098340402,
			"strokeColor": "#000000",
			"backgroundColor": "brown",
			"width": 79.4343095276238,
			"height": 2.2065085979895485,
			"seed": 905998516,
			"groupIds": [
				"G3qkxMnpIZSGXCk8PY7HM",
				"63ne4JnFaBkJG6f9wx0Ty",
				"V8W2XckbDyZllfYeTaSWo",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					79.4343095276238,
					-2.2065085979895485
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1229,
			"versionNonce": 2100404236,
			"isDeleted": false,
			"id": "oh_EuexCy3To8QqCCz0Zc",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -163.11920054991018,
			"y": 71.84699258106264,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 26.530914396861096,
			"height": 28.99890643377838,
			"seed": 2097357964,
			"groupIds": [
				"ePjqGr2KCbn_tkll3Jdhs",
				"63ne4JnFaBkJG6f9wx0Ty",
				"V8W2XckbDyZllfYeTaSWo",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false
		},
		{
			"type": "freedraw",
			"version": 1065,
			"versionNonce": 1614886580,
			"isDeleted": false,
			"id": "FK4yTaSsqXpok3TPDNvcF",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -140.29027420842485,
			"y": 88.27194281179591,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 0,
			"height": 0.6169980092293275,
			"seed": 597178932,
			"groupIds": [
				"ePjqGr2KCbn_tkll3Jdhs",
				"63ne4JnFaBkJG6f9wx0Ty",
				"V8W2XckbDyZllfYeTaSWo",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					-0.38300199077067254
				],
				[
					0,
					-1
				],
				[
					0,
					-0.38300199077067254
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.140625,
				0.435546875,
				0
			]
		},
		{
			"type": "rectangle",
			"version": 1115,
			"versionNonce": 681164428,
			"isDeleted": false,
			"id": "zlGPFq11qvjcPvelKXPh4",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -184.99172939540077,
			"y": 48.45253464681284,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 19.834254066627754,
			"height": 18.632178062589702,
			"seed": 751219468,
			"groupIds": [
				"Mhi_XvAomZg8X11MnYjhU",
				"63ne4JnFaBkJG6f9wx0Ty",
				"V8W2XckbDyZllfYeTaSWo",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 1148,
			"versionNonce": 365969460,
			"isDeleted": false,
			"id": "6cjk0gZL-L1VijdFTaw7I",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -173.3580838442232,
			"y": 49.13150483444675,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 0.1719399314226955,
			"height": 18.039670951388143,
			"seed": 1853543348,
			"groupIds": [
				"Mhi_XvAomZg8X11MnYjhU",
				"63ne4JnFaBkJG6f9wx0Ty",
				"V8W2XckbDyZllfYeTaSWo",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.1719399314226955,
					18.039670951388143
				]
			]
		},
		{
			"type": "line",
			"version": 1132,
			"versionNonce": 511315212,
			"isDeleted": false,
			"id": "6FKiB2ASVVWCnWodJIbWZ",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -184.58787837728502,
			"y": 57.91035850564213,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 20.148830007043877,
			"height": 0.5103508827903366,
			"seed": 1779724684,
			"groupIds": [
				"Mhi_XvAomZg8X11MnYjhU",
				"63ne4JnFaBkJG6f9wx0Ty",
				"V8W2XckbDyZllfYeTaSWo",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					20.148830007043877,
					0.5103508827903366
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1148,
			"versionNonce": 667031988,
			"isDeleted": false,
			"id": "jy_5wTRyJJZ-ovl5VFxML",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -131.0680511824556,
			"y": 50.98069348798753,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 19.834254066627754,
			"height": 18.632178062589702,
			"seed": 1154366772,
			"groupIds": [
				"m00FAc_U5aRtJIrM6FTut",
				"63ne4JnFaBkJG6f9wx0Ty",
				"V8W2XckbDyZllfYeTaSWo",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 1181,
			"versionNonce": 1078758284,
			"isDeleted": false,
			"id": "oBG3rN_SyEBOM4FPrFfg0",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -119.43029281759678,
			"y": 51.869996016025745,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 0.1719399314226955,
			"height": 18.039670951388143,
			"seed": 1680236556,
			"groupIds": [
				"m00FAc_U5aRtJIrM6FTut",
				"63ne4JnFaBkJG6f9wx0Ty",
				"V8W2XckbDyZllfYeTaSWo",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.1719399314226955,
					18.039670951388143
				]
			]
		},
		{
			"type": "line",
			"version": 1165,
			"versionNonce": 557630260,
			"isDeleted": false,
			"id": "43IStEbFKwgJpm0SnJa3c",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -130.67803012533867,
			"y": 60.34990126888962,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 20.148830007043877,
			"height": 0.5103508827903366,
			"seed": 536377012,
			"groupIds": [
				"m00FAc_U5aRtJIrM6FTut",
				"63ne4JnFaBkJG6f9wx0Ty",
				"V8W2XckbDyZllfYeTaSWo",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					20.148830007043877,
					0.5103508827903366
				]
			]
		},
		{
			"type": "line",
			"version": 2685,
			"versionNonce": 810236428,
			"isDeleted": false,
			"id": "gfNkonsxKY9gBEeuk0leV",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -195.86222222214,
			"y": 107.41494551578349,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 329.99058656713225,
			"height": 75.39259838634437,
			"seed": 1534880652,
			"groupIds": [
				"V8W2XckbDyZllfYeTaSWo",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					94.94260708969324,
					0.11287160082096397
				],
				[
					200.3338954451318,
					75.39259838634437
				],
				[
					-129.6566911220005,
					75.38180600750471
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "text",
			"version": 561,
			"versionNonce": 950418612,
			"isDeleted": false,
			"id": "Idi7Ilwn",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -239.12130380930796,
			"y": 138.21214734813364,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"width": 56,
			"height": 30,
			"seed": 1826054196,
			"groupIds": [
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false,
			"fontSize": 23.98036006546641,
			"fontFamily": 1,
			"text": "Sand",
			"rawText": "Sand",
			"baseline": 21,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Sand"
		},
		{
			"type": "line",
			"version": 302,
			"versionNonce": 963647628,
			"isDeleted": false,
			"id": "NLKQbhr4tuPaVsL1oO2SI",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -178.35207304007693,
			"y": 152.59676273274906,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"width": 27.69230769230768,
			"height": 1.5384615384615188,
			"seed": 1164950452,
			"groupIds": [
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					27.69230769230768,
					1.5384615384615188
				]
			]
		},
		{
			"type": "text",
			"version": 253,
			"versionNonce": 1738835508,
			"isDeleted": false,
			"id": "TCK0TbQL",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -139.12130380930788,
			"y": 137.44291657890287,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"width": 80,
			"height": 25,
			"seed": 373974708,
			"groupIds": [
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "X Truth",
			"rawText": "X Truth",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "X Truth"
		},
		{
			"type": "rectangle",
			"version": 1585,
			"versionNonce": 930424588,
			"isDeleted": false,
			"id": "X6qfOrgBLis_C9220uJ7d",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.487820813650341,
			"x": -310.1323991811702,
			"y": 56.80265518057376,
			"strokeColor": "#000000",
			"backgroundColor": "brown",
			"width": 84.47778548986334,
			"height": 70.00637763702996,
			"seed": 1254322956,
			"groupIds": [
				"cz8BBjHvMC0Qii31o19gK",
				"18_7HvflG0U0lOrjdj2sc",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [
				{
					"id": "TRG3iTKDiZ49HuQ5vJz7y",
					"type": "arrow"
				}
			],
			"updated": 1659243100326,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 3636,
			"versionNonce": 2127848844,
			"isDeleted": false,
			"id": "Pk3TGCWipd8u1I1Oyx_4s",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 4.819877973088465,
			"x": -348.30480892171886,
			"y": 37.58067049138997,
			"strokeColor": "#000000",
			"backgroundColor": "brown",
			"width": 107.0374788746717,
			"height": 43.10825654658188,
			"seed": 1269437364,
			"groupIds": [
				"hUAKprV0STHRfx4lL0SYS",
				"cz8BBjHvMC0Qii31o19gK",
				"18_7HvflG0U0lOrjdj2sc",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					30.796082416738564,
					0.0645381380819315
				],
				[
					64.98135393697558,
					43.10825654658188
				],
				[
					-42.056124937696126,
					43.102085640608024
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 1691,
			"versionNonce": 1396148532,
			"isDeleted": false,
			"id": "VALOqY0XVmv2WpRpc6tmo",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 4.814963905451178,
			"x": -337.09011523535304,
			"y": 48.60996042508596,
			"strokeColor": "#000000",
			"backgroundColor": "brown",
			"width": 0,
			"height": 42.47215777672616,
			"seed": 712585612,
			"groupIds": [
				"hUAKprV0STHRfx4lL0SYS",
				"cz8BBjHvMC0Qii31o19gK",
				"18_7HvflG0U0lOrjdj2sc",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0,
					42.47215777672616
				]
			]
		},
		{
			"type": "line",
			"version": 1592,
			"versionNonce": 1153946636,
			"isDeleted": false,
			"id": "IkyHftIxMwVUQ2vjZgRZj",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 4.814963905451178,
			"x": -333.45212871614996,
			"y": 18.88678029828337,
			"strokeColor": "#000000",
			"backgroundColor": "brown",
			"width": 0,
			"height": 44.707534501816944,
			"seed": 974486836,
			"groupIds": [
				"hUAKprV0STHRfx4lL0SYS",
				"cz8BBjHvMC0Qii31o19gK",
				"18_7HvflG0U0lOrjdj2sc",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100326,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0,
					44.707534501816944
				]
			]
		},
		{
			"type": "line",
			"version": 1704,
			"versionNonce": 727204532,
			"isDeleted": false,
			"id": "9QOgY3H7szfMzIc2O7ZXD",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 4.814963905451178,
			"x": -368.67002856765504,
			"y": 53.313605795822426,
			"strokeColor": "#000000",
			"backgroundColor": "brown",
			"width": 53.64904140218035,
			"height": 0,
			"seed": 972234764,
			"groupIds": [
				"hUAKprV0STHRfx4lL0SYS",
				"cz8BBjHvMC0Qii31o19gK",
				"18_7HvflG0U0lOrjdj2sc",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100327,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					53.64904140218035,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 1698,
			"versionNonce": 122253964,
			"isDeleted": false,
			"id": "l8c40rZRAIXYx1kmZxj7R",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 4.814963905451178,
			"x": -367.05005272639596,
			"y": 60.18281102019083,
			"strokeColor": "#000000",
			"backgroundColor": "brown",
			"width": 80.47356210327055,
			"height": 2.235376725090847,
			"seed": 1784133300,
			"groupIds": [
				"hUAKprV0STHRfx4lL0SYS",
				"cz8BBjHvMC0Qii31o19gK",
				"18_7HvflG0U0lOrjdj2sc",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100327,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					80.47356210327055,
					-2.235376725090847
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1323,
			"versionNonce": 36031540,
			"isDeleted": false,
			"id": "pAqYJ9vFbK2VBYAKijaSp",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.487820813650341,
			"x": -269.60469813510787,
			"y": 87.83112926071612,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 26.530914396861096,
			"height": 28.99890643377838,
			"seed": 1361788556,
			"groupIds": [
				"MGgqgcAxqo-QpWyYl48iq",
				"cz8BBjHvMC0Qii31o19gK",
				"18_7HvflG0U0lOrjdj2sc",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243100327,
			"link": null,
			"locked": false
		},
		{
			"type": "freedraw",
			"version": 1159,
			"versionNonce": 1964196108,
			"isDeleted": false,
			"id": "EUQpm1N3t2eQ8dDC0E7m7",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.487820813650341,
			"x": -248.76335826774897,
			"y": 97.05645777149321,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 0,
			"height": 0.6169980092293275,
			"seed": 420921396,
			"groupIds": [
				"MGgqgcAxqo-QpWyYl48iq",
				"cz8BBjHvMC0Qii31o19gK",
				"18_7HvflG0U0lOrjdj2sc",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100327,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					-0.38300199077067254
				],
				[
					0,
					-1
				],
				[
					0,
					-0.38300199077067254
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.140625,
				0.435546875,
				0
			]
		},
		{
			"type": "rectangle",
			"version": 1209,
			"versionNonce": 159786420,
			"isDeleted": false,
			"id": "nIJHBMuh_8-_gWigTGA-o",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.487820813650341,
			"x": -304.3195479471096,
			"y": 91.02000695203117,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 19.834254066627754,
			"height": 18.632178062589702,
			"seed": 953912588,
			"groupIds": [
				"FKC41VLjc1d5DGCHEGuf7",
				"cz8BBjHvMC0Qii31o19gK",
				"18_7HvflG0U0lOrjdj2sc",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243100327,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 1242,
			"versionNonce": 1436499852,
			"isDeleted": false,
			"id": "uBzHvOOewXfD6X2KuT21Q",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.487820813650341,
			"x": -292.9290718101162,
			"y": 90.93177112983203,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 0.1719399314226955,
			"height": 18.039670951388143,
			"seed": 2117638580,
			"groupIds": [
				"FKC41VLjc1d5DGCHEGuf7",
				"cz8BBjHvMC0Qii31o19gK",
				"18_7HvflG0U0lOrjdj2sc",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100327,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.1719399314226955,
					18.039670951388143
				]
			]
		},
		{
			"type": "line",
			"version": 1226,
			"versionNonce": 1184845620,
			"isDeleted": false,
			"id": "9fp8q8YX-0OvR9Vk2kvyR",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.487820813650341,
			"x": -303.8713277010528,
			"y": 100.40390027287675,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 20.148830007043877,
			"height": 0.5103508827903366,
			"seed": 310250380,
			"groupIds": [
				"FKC41VLjc1d5DGCHEGuf7",
				"cz8BBjHvMC0Qii31o19gK",
				"18_7HvflG0U0lOrjdj2sc",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100327,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					20.148830007043877,
					0.5103508827903366
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1242,
			"versionNonce": 1898409484,
			"isDeleted": false,
			"id": "8p7xKXlM-NrVwi_pJokDb",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.487820813650341,
			"x": -264.7662451678882,
			"y": 54.28186739115096,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 19.834254066627754,
			"height": 18.632178062589702,
			"seed": 1692615476,
			"groupIds": [
				"uR63Is5bOozKfzylKTpwz",
				"cz8BBjHvMC0Qii31o19gK",
				"18_7HvflG0U0lOrjdj2sc",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243100327,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 1275,
			"versionNonce": 701974708,
			"isDeleted": false,
			"id": "ACXoUPp5JfkOaP6iu2lgs",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.487820813650341,
			"x": -252.87698049777003,
			"y": 54.19629117279031,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 0.1719399314226955,
			"height": 18.039670951388143,
			"seed": 1078770188,
			"groupIds": [
				"uR63Is5bOozKfzylKTpwz",
				"cz8BBjHvMC0Qii31o19gK",
				"18_7HvflG0U0lOrjdj2sc",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100327,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.1719399314226955,
					18.039670951388143
				]
			]
		},
		{
			"type": "line",
			"version": 1259,
			"versionNonce": 2024131724,
			"isDeleted": false,
			"id": "G9oYQBu5EPyWsc1l626wD",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 5.487820813650341,
			"x": -264.8372277735004,
			"y": 63.395846929290585,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 20.148830007043877,
			"height": 0.5103508827903366,
			"seed": 1132248244,
			"groupIds": [
				"uR63Is5bOozKfzylKTpwz",
				"cz8BBjHvMC0Qii31o19gK",
				"18_7HvflG0U0lOrjdj2sc",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100327,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					20.148830007043877,
					0.5103508827903366
				]
			]
		},
		{
			"type": "text",
			"version": 309,
			"versionNonce": 651432500,
			"isDeleted": false,
			"id": "k4csiSPv",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -313.7366884246919,
			"y": -24.09554495955868,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"width": 104,
			"height": 25,
			"seed": 638406580,
			"groupIds": [
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243100327,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Fell Great",
			"rawText": "Fell Great",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Fell Great"
		},
		{
			"type": "arrow",
			"version": 542,
			"versionNonce": 494809524,
			"isDeleted": false,
			"id": "TRG3iTKDiZ49HuQ5vJz7y",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -191.4289961169996,
			"y": 3.3659935019798155,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"width": 83.10663997487308,
			"height": 29.690618887887545,
			"seed": 622681996,
			"groupIds": [
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100350,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "X6qfOrgBLis_C9220uJ7d",
				"focus": -1.152523700328801,
				"gap": 10.865983593965424
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-83.10663997487308,
					29.690618887887545
				]
			]
		},
		{
			"type": "ellipse",
			"version": 2591,
			"versionNonce": 1283173300,
			"isDeleted": false,
			"id": "Zqq6DEK3THuZP8ugilXB8",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.415424045362423,
			"x": -102.40316650169945,
			"y": 76.7264906561416,
			"strokeColor": "#000000",
			"backgroundColor": "beige",
			"width": 9.740303643343353,
			"height": 9.826853215637543,
			"seed": 1005406476,
			"groupIds": [
				"jtj4yRtfUY6iV5-EyOXjM",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243100327,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 2547,
			"versionNonce": 187505036,
			"isDeleted": false,
			"id": "G5Z9xagBKK_IY2eI-bFU5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.415424045362423,
			"x": -98.41693516464628,
			"y": 85.9397879657101,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0.26204941908366747,
			"height": 13.626569792350752,
			"seed": 993041844,
			"groupIds": [
				"jtj4yRtfUY6iV5-EyOXjM",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100327,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.26204941908366747,
					13.626569792350752
				]
			]
		},
		{
			"type": "line",
			"version": 2523,
			"versionNonce": 1559500084,
			"isDeleted": false,
			"id": "6RFflp744HlpEUhrH1EzJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.415424045362423,
			"x": -99.9279610493434,
			"y": 97.97226299004593,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 1.703321224043844,
			"height": 8.647630829761045,
			"seed": 1140344716,
			"groupIds": [
				"jtj4yRtfUY6iV5-EyOXjM",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100327,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.703321224043844,
					8.647630829761045
				]
			]
		},
		{
			"type": "line",
			"version": 2529,
			"versionNonce": 736757772,
			"isDeleted": false,
			"id": "fuEcqnYFZP3QKkjGzmXhH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.415424045362423,
			"x": -100.06847739829627,
			"y": 99.04542640069475,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 1.9653706431275086,
			"height": 8.647630829761045,
			"seed": 1278920500,
			"groupIds": [
				"jtj4yRtfUY6iV5-EyOXjM",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100327,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.9653706431275086,
					8.647630829761045
				]
			]
		},
		{
			"type": "line",
			"version": 2825,
			"versionNonce": 1705201332,
			"isDeleted": false,
			"id": "xOfOuCamNqrMkZCsD6XYD",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.415424045362423,
			"x": -98.57440155360092,
			"y": 90.81242593840035,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 5.450884951357988,
			"height": 4.2407792644668,
			"seed": 1059026444,
			"groupIds": [
				"jtj4yRtfUY6iV5-EyOXjM",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100327,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					5.450884951357988,
					-4.2407792644668
				]
			]
		},
		{
			"type": "line",
			"version": 2735,
			"versionNonce": 872752780,
			"isDeleted": false,
			"id": "yt9gfXdMq_H8TNSX-hDUL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.415424045362423,
			"x": -99.26651092565044,
			"y": 89.78891818316477,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 2.8818663090518677,
			"height": 8.202631557770212,
			"seed": 1564721332,
			"groupIds": [
				"jtj4yRtfUY6iV5-EyOXjM",
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243100327,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-2.8818663090518677,
					8.202631557770212
				]
			]
		},
		{
			"type": "text",
			"version": 229,
			"versionNonce": 1462720564,
			"isDeleted": false,
			"id": "I9ohWPsd",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -92.96745765546001,
			"y": 55.904455040441164,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"width": 65,
			"height": 25,
			"seed": 565350540,
			"groupIds": [
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243100327,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Foolish",
			"rawText": "Foolish",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Foolish"
		},
		{
			"type": "text",
			"version": 524,
			"versionNonce": 1173406604,
			"isDeleted": false,
			"id": "PW9iwtmd",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -319.7506744386768,
			"y": -156.40323726725154,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"width": 337,
			"height": 25,
			"seed": 1721175604,
			"groupIds": [
				"ph5504tHr4SsS2FW54rWB"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659243102943,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "The Church of Babylon the Great",
			"rawText": "The Church of Babylon the Great",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "The Church of Babylon the Great"
		},
		{
			"type": "line",
			"version": 619,
			"versionNonce": 1671965108,
			"isDeleted": false,
			"id": "2g3MiromHLpRgRFzN3ZAH",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 34.900855736355844,
			"y": -162.26789550869032,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"width": 0.161069660347259,
			"height": 363.29272472614343,
			"seed": 1522183052,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243377134,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.161069660347259,
					363.29272472614343
				]
			]
		},
		{
			"type": "arrow",
			"version": 261,
			"versionNonce": 1116105228,
			"isDeleted": false,
			"id": "mA2qK2RcKLkQhtdn-eBCm",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -148.12492565975373,
			"y": -53.98438312296116,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"width": 0.20717896735982322,
			"height": 44.13885386125605,
			"seed": 1675571724,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243265341,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "hCGUMSfX",
				"focus": 0.03199194995802334,
				"gap": 7.255677657384979
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					0.20717896735982322,
					44.13885386125605
				]
			]
		},
		{
			"type": "arrow",
			"version": 679,
			"versionNonce": 1473129100,
			"isDeleted": false,
			"id": "WnCe9OcvoTELvxiYJwt58",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 257.1568136022571,
			"y": -58.36744523578585,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"width": 1.283482868955602,
			"height": 45.01717851893466,
			"seed": 1839708468,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659243312592,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "aR44HW80",
				"focus": -0.054959785405674796,
				"gap": 2.6147484116933697
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-1.283482868955602,
					45.01717851893466
				]
			]
		},
		{
			"type": "text",
			"version": 221,
			"versionNonce": 2136214196,
			"isDeleted": false,
			"id": "aR44HW80",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 181.61105805305465,
			"y": -85.98219364747922,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"width": 144,
			"height": 25,
			"seed": 222031412,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "WnCe9OcvoTELvxiYJwt58",
					"type": "arrow"
				}
			],
			"updated": 1659243312592,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Head -> Christ",
			"rawText": "Head -> Christ",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Head -> Christ"
		},
		{
			"id": "hCGUMSfX",
			"type": "text",
			"x": -228.07644194694535,
			"y": -86.24006078034614,
			"width": 165,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 315230348,
			"version": 179,
			"versionNonce": 1485265164,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "mA2qK2RcKLkQhtdn-eBCm",
					"type": "arrow"
				}
			],
			"updated": 1659243304291,
			"link": null,
			"locked": false,
			"text": "Head -> X Christ",
			"rawText": "Head -> X Christ",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": "Head -> X Christ"
		},
		{
			"id": "O9QxVU7ovQZbmyUbVPi-W",
			"type": "text",
			"x": 429.29993167942814,
			"y": -188.14940143968676,
			"width": 11,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "#868e96",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1404054028,
			"version": 3,
			"versionNonce": 45549708,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1659243395877,
			"link": null,
			"locked": false,
			"text": "",
			"rawText": "",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": ""
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "#868e96",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStrokeSharpness": "sharp",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"currentItemLinearStrokeSharpness": "round",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%