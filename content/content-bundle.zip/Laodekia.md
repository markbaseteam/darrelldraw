---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
PHILADELPHIA ^goMNM4NB

SYNAGOGUE OF SATAN ^2cPDPqtV

144.000 ^h8wy2gBJ

Profesed Adventist
Nominal Adventist ^FSX6LbV8

Spirit of God
Abide ^d4LEuUXq

Spirit of God
Abide ^pqya9RNe

False Church ^CVsftzlq

True Church ^L5FkWiC8

Jesus - God the Son ^B9serjiU

Jesus - Son of God ^RWhCEHUi

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"id": "goMNM4NB",
			"type": "text",
			"x": -98,
			"y": -180.5,
			"width": 151,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 985831680,
			"version": 17,
			"versionNonce": 1544574720,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "jtMSOJb1GsLqDVH7Wmqjq",
					"type": "arrow"
				}
			],
			"updated": 1658739520946,
			"link": null,
			"locked": false,
			"text": "PHILADELPHIA",
			"rawText": "PHILADELPHIA",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": "PHILADELPHIA"
		},
		{
			"id": "2cPDPqtV",
			"type": "text",
			"x": 120,
			"y": -182.5,
			"width": 265,
			"height": 28,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1272551680,
			"version": 114,
			"versionNonce": 1213306624,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "7H6EcJxohMUm-VnoSVkd5",
					"type": "arrow"
				}
			],
			"updated": 1658739526300,
			"link": null,
			"locked": false,
			"text": "SYNAGOGUE OF SATAN",
			"rawText": "SYNAGOGUE OF SATAN",
			"fontSize": 22.405063291139236,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 20,
			"containerId": null,
			"originalText": "SYNAGOGUE OF SATAN"
		},
		{
			"id": "jtMSOJb1GsLqDVH7Wmqjq",
			"type": "arrow",
			"x": -39,
			"y": -142.5,
			"width": 0,
			"height": 42,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1682953984,
			"version": 71,
			"versionNonce": 1340324096,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1658739520946,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					42
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "goMNM4NB",
				"focus": 0.2185430463576159,
				"gap": 13
			},
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "7H6EcJxohMUm-VnoSVkd5",
			"type": "arrow",
			"x": 245,
			"y": -146.5,
			"width": 1,
			"height": 43,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1829017856,
			"version": 51,
			"versionNonce": 1521383680,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1658739526300,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					1,
					43
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "2cPDPqtV",
				"focus": 0.06031690449093932,
				"gap": 8
			},
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "h8wy2gBJ",
			"type": "text",
			"x": -74,
			"y": -81.5,
			"width": 79,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1349998848,
			"version": 12,
			"versionNonce": 948672256,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "rpvYLGb6f6Ke3RGdK0tkn",
					"type": "arrow"
				}
			],
			"updated": 1658739588951,
			"link": null,
			"locked": false,
			"text": "144.000",
			"rawText": "144.000",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": "144.000"
		},
		{
			"id": "FSX6LbV8",
			"type": "text",
			"x": 150,
			"y": -83.5,
			"width": 190,
			"height": 50,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 167008000,
			"version": 88,
			"versionNonce": 1237890816,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "NVP7HPRyHxsTcnN2MFC4S",
					"type": "arrow"
				}
			],
			"updated": 1658739600131,
			"link": null,
			"locked": false,
			"text": "Profesed Adventist\nNominal Adventist",
			"rawText": "Profesed Adventist\nNominal Adventist",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 43,
			"containerId": null,
			"originalText": "Profesed Adventist\nNominal Adventist"
		},
		{
			"id": "rpvYLGb6f6Ke3RGdK0tkn",
			"type": "arrow",
			"x": -39,
			"y": -46.5,
			"width": 1.3069077658001333,
			"height": 71.80476293823682,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1738807040,
			"version": 116,
			"versionNonce": 1006483200,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1658739595378,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					1.3069077658001333,
					71.80476293823682
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "h8wy2gBJ",
				"focus": 0.12357983325075121,
				"gap": 10
			},
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "NVP7HPRyHxsTcnN2MFC4S",
			"type": "arrow",
			"x": 248,
			"y": -21.5,
			"width": 2.0719566368404685,
			"height": 43.9582896232605,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1427978496,
			"version": 84,
			"versionNonce": 187717376,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1658739656972,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					2.0719566368404685,
					43.9582896232605
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "FSX6LbV8",
				"focus": -0.013059273748908147,
				"gap": 12
			},
			"endBinding": {
				"elementId": "pqya9RNe",
				"focus": 0.02746974840236147,
				"gap": 12.041710376739502
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "d4LEuUXq",
			"type": "text",
			"x": -105,
			"y": 41.5,
			"width": 130,
			"height": 50,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 495073536,
			"version": 83,
			"versionNonce": 591599360,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "A7WuK8Ygfzkx0KWwRY6Sb",
					"type": "arrow"
				},
				{
					"id": "L8LaesyVwIMGjwMUs1TRx",
					"type": "arrow"
				}
			],
			"updated": 1658739951096,
			"link": null,
			"locked": false,
			"text": "Spirit of God\nAbide",
			"rawText": "Spirit of God\nAbide",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 43,
			"containerId": null,
			"originalText": "Spirit of God\nAbide"
		},
		{
			"id": "pqya9RNe",
			"type": "text",
			"x": 185,
			"y": 34.5,
			"width": 130,
			"height": 50,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1138693888,
			"version": 51,
			"versionNonce": 320428288,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "NVP7HPRyHxsTcnN2MFC4S",
					"type": "arrow"
				},
				{
					"id": "Pep2pHKf4qF682Pn-7axf",
					"type": "arrow"
				}
			],
			"updated": 1658739707374,
			"link": null,
			"locked": false,
			"text": "Spirit of God\nAbide",
			"rawText": "Spirit of God\nAbide",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 43,
			"containerId": null,
			"originalText": "Spirit of God\nAbide"
		},
		{
			"id": "Pep2pHKf4qF682Pn-7axf",
			"type": "arrow",
			"x": 249,
			"y": 99.5,
			"width": 0.29308293319306244,
			"height": 41.23921228191816,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1743485184,
			"version": 74,
			"versionNonce": 1104238848,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1658739732774,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-0.29308293319306244,
					41.23921228191816
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "pqya9RNe",
				"focus": 0.010981122776338373,
				"gap": 15
			},
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "CVsftzlq",
			"type": "text",
			"x": 183,
			"y": 157.5,
			"width": 126,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1216657152,
			"version": 95,
			"versionNonce": 927127808,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "nIbc2DU9ZEDwbm4A83aHo",
					"type": "arrow"
				}
			],
			"updated": 1658739764469,
			"link": null,
			"locked": false,
			"text": "False Church",
			"rawText": "False Church",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": "False Church"
		},
		{
			"id": "A7WuK8Ygfzkx0KWwRY6Sb",
			"type": "arrow",
			"x": -35,
			"y": 102.5,
			"width": 0,
			"height": 44,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 2127010048,
			"version": 43,
			"versionNonce": 1546483456,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1658739755834,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					44
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "d4LEuUXq",
				"focus": -0.07692307692307693,
				"gap": 11
			},
			"endBinding": {
				"elementId": "L5FkWiC8",
				"focus": 0,
				"gap": 15
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "L5FkWiC8",
			"type": "text",
			"x": -95.5,
			"y": 161.5,
			"width": 121,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 2087474944,
			"version": 64,
			"versionNonce": 1623816448,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "A7WuK8Ygfzkx0KWwRY6Sb",
					"type": "arrow"
				}
			],
			"updated": 1658739755834,
			"link": null,
			"locked": false,
			"text": "True Church",
			"rawText": "True Church",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": "True Church"
		},
		{
			"id": "nIbc2DU9ZEDwbm4A83aHo",
			"type": "arrow",
			"x": 251,
			"y": 195.5,
			"width": 1.9715160264704252,
			"height": 48.1240173010342,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1786492672,
			"version": 100,
			"versionNonce": 1496234240,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1658739815373,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-1.9715160264704252,
					48.1240173010342
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "CVsftzlq",
				"focus": -0.09517351016063753,
				"gap": 13
			},
			"endBinding": {
				"elementId": "B9serjiU",
				"focus": 0.03720486807069764,
				"gap": 14.8759826989658
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "B9serjiU",
			"type": "text",
			"x": 139.5,
			"y": 258.5,
			"width": 209,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1684322560,
			"version": 90,
			"versionNonce": 552949504,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "nIbc2DU9ZEDwbm4A83aHo",
					"type": "arrow"
				}
			],
			"updated": 1658739815373,
			"link": null,
			"locked": false,
			"text": "Jesus - God the Son",
			"rawText": "Jesus - God the Son",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": "Jesus - God the Son"
		},
		{
			"id": "L8LaesyVwIMGjwMUs1TRx",
			"type": "arrow",
			"x": 51.64623338864051,
			"y": 43.028565313815825,
			"width": 46.17058675105625,
			"height": 190.26573508195463,
			"angle": 6.051406927923906,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 2059753728,
			"version": 799,
			"versionNonce": 2086992128,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1658739951096,
			"link": null,
			"locked": false,
			"points": [
				[
					-0.5681662645816159,
					0
				],
				[
					25.68569678994057,
					3.0361553470524676
				],
				[
					40.17058675105625,
					165.9764923055349
				],
				[
					-6,
					190.26573508195463
				]
			],
			"lastCommittedPoint": [
				-6,
				188
			],
			"startBinding": {
				"elementId": "d4LEuUXq",
				"focus": -0.26023756511061485,
				"gap": 5.746179002460053
			},
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "RWhCEHUi",
			"type": "text",
			"x": -152,
			"y": 228.5,
			"width": 198,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 1810266368,
			"version": 76,
			"versionNonce": 1504294656,
			"isDeleted": false,
			"boundElements": [],
			"updated": 1658739948443,
			"link": null,
			"locked": false,
			"text": "Jesus - Son of God",
			"rawText": "Jesus - Son of God",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": "Jesus - Son of God"
		},
		{
			"id": "CzJwum9F3HB3HnvEXOVQ_",
			"type": "arrow",
			"x": 254,
			"y": 100.5,
			"width": 84,
			"height": 57,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1776908544,
			"version": 215,
			"versionNonce": 1157306624,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1658739699509,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					3,
					43
				],
				[
					-61,
					57
				],
				[
					-29,
					28
				],
				[
					-81,
					32
				]
			],
			"lastCommittedPoint": [
				-29,
				28
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "ySIbLAybub13yUS96zmHe",
			"type": "arrow",
			"x": 48,
			"y": 54.5,
			"width": 37,
			"height": 183,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 351246592,
			"version": 385,
			"versionNonce": 1796708608,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1658739845106,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					33,
					36
				],
				[
					34,
					109
				],
				[
					-3,
					183
				],
				[
					5,
					172
				]
			],
			"lastCommittedPoint": [
				-3,
				183
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "center",
		"currentItemStrokeSharpness": "sharp",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"currentItemLinearStrokeSharpness": "round",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%