---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
  Hawa ada iman (Faith) ^Am8oh8qV

X mkn buah dr pohon 
pengetahuan Baik & Jahat ^uJKiGJkZ

Gen 3:6 ^hwXtHsPE

Hawa X ada Iman (Faith) ^HciyeV0m

Melihat / Makan buah dr pohon 
pengetahuan Baik & Jahat ^Kgmuara7

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"type": "text",
			"version": 250,
			"versionNonce": 1618891569,
			"isDeleted": false,
			"id": "Kgmuara7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 56.412470962658375,
			"y": -18.43270027543224,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 317,
			"height": 50,
			"seed": 96495,
			"groupIds": [
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801543635,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Melihat / Makan buah dr pohon \npengetahuan Baik & Jahat",
			"rawText": "Melihat / Makan buah dr pohon \npengetahuan Baik & Jahat",
			"baseline": 43,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Melihat / Makan buah dr pohon \npengetahuan Baik & Jahat"
		},
		{
			"type": "rectangle",
			"version": 1154,
			"versionNonce": 1577617489,
			"isDeleted": false,
			"id": "Br0gKwr7iPKQ6FGlgpFDy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -365.7524687480203,
			"y": -147.17537324062812,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 801.6000671386719,
			"height": 298.2545249245384,
			"seed": 90168273,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 747,
			"versionNonce": 1256169791,
			"isDeleted": false,
			"id": "ImLPJtlqrmVS-2iBZ8Dpr",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 20.27827653818767,
			"y": -149.02161394450434,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 3.9860545338450493,
			"height": 299.39580701281136,
			"seed": 1710835135,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					3.9860545338450493,
					299.39580701281136
				]
			]
		},
		{
			"type": "line",
			"version": 554,
			"versionNonce": 223696433,
			"isDeleted": false,
			"id": "oz7SLZnId62Gl_j8Yqlm4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -370.5526091288797,
			"y": -58.37540070644832,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 802.8001098632812,
			"height": 4.79998779296875,
			"seed": 91634097,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					802.8001098632812,
					4.79998779296875
				]
			]
		},
		{
			"type": "text",
			"version": 684,
			"versionNonce": 502735199,
			"isDeleted": false,
			"id": "Am8oh8qV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -356.1525847148172,
			"y": -118.66628732532274,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 341,
			"height": 36,
			"seed": 1600665055,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "v8yXDBmqq1vwXGzTI0WHK",
					"type": "arrow"
				}
			],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "  Hawa ada iman (Faith)",
			"rawText": "  Hawa ada iman (Faith)",
			"baseline": 25,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "  Hawa ada iman (Faith)"
		},
		{
			"type": "arrow",
			"version": 1962,
			"versionNonce": 1279608401,
			"isDeleted": false,
			"id": "v8yXDBmqq1vwXGzTI0WHK",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -331.8002220875567,
			"y": -73.06628630807009,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 60.00007120768231,
			"height": 63.09087441184306,
			"seed": 1388698513,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1665801541430,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "Am8oh8qV",
				"focus": 0.6909948019749234,
				"gap": 9.600001017252652
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-21.152441972963857,
					29.890897808652966
				],
				[
					-10.752387041323232,
					63.09087441184306
				],
				[
					38.847629234718454,
					62.63934116948664
				]
			]
		},
		{
			"type": "text",
			"version": 727,
			"versionNonce": 749223409,
			"isDeleted": false,
			"id": "uJKiGJkZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -269.3524138163797,
			"y": -22.57541799974257,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 268,
			"height": 50,
			"seed": 163848703,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "X mkn buah dr pohon \npengetahuan Baik & Jahat",
			"rawText": "X mkn buah dr pohon \npengetahuan Baik & Jahat",
			"baseline": 43,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "X mkn buah dr pohon \npengetahuan Baik & Jahat"
		},
		{
			"type": "line",
			"version": 1770,
			"versionNonce": 2138543519,
			"isDeleted": false,
			"id": "1xsvWiFAjqfY4y5yXEG5E",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.305891026715994,
			"x": 388.34778223492435,
			"y": -143.59006136594638,
			"strokeColor": "#000000",
			"backgroundColor": "#fa5252",
			"width": 121.2000732421875,
			"height": 258.00001525878906,
			"seed": 2105950577,
			"groupIds": [
				"WYZFa8305qs_OvbWQveS8",
				"s-NHXfGnxoCvI2xYXRyKt",
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					42,
					205.1999969482422
				],
				[
					66,
					248.3999481201172
				],
				[
					84.0001220703125,
					207.59999084472656
				],
				[
					106.800048828125,
					250.8000030517578
				],
				[
					121.2000732421875,
					206.40000915527344
				],
				[
					74.4000244140625,
					-7.20001220703125
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1145,
			"versionNonce": 95246289,
			"isDeleted": false,
			"id": "9RkAiS2D8QAsJS2oHiqVJ",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.170361189156033,
			"x": 394.6041080941419,
			"y": -150.11393228262085,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 70.39978469496123,
			"height": 11.851817827043417,
			"seed": 906856991,
			"groupIds": [
				"WYZFa8305qs_OvbWQveS8",
				"s-NHXfGnxoCvI2xYXRyKt",
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1919,
			"versionNonce": 2018609599,
			"isDeleted": false,
			"id": "hwXtHsPE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 1.3941405970680831,
			"x": 369.4123373491158,
			"y": -61.28065807668213,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 158,
			"height": 52,
			"seed": 587131729,
			"groupIds": [
				"s-NHXfGnxoCvI2xYXRyKt",
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"fontSize": 40.7008884810586,
			"fontFamily": 1,
			"text": "Gen 3:6",
			"rawText": "Gen 3:6",
			"baseline": 36,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Gen 3:6"
		},
		{
			"type": "text",
			"version": 547,
			"versionNonce": 380908977,
			"isDeleted": false,
			"id": "HciyeV0m",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 39.04734611200578,
			"y": -118.87541087897446,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 353,
			"height": 36,
			"seed": 1093987903,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Hawa X ada Iman (Faith)",
			"rawText": "Hawa X ada Iman (Faith)",
			"baseline": 25,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Hawa X ada Iman (Faith)"
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 102234591,
			"isDeleted": false,
			"id": "asVAmgZuFur5mcIsL3uSu",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 11.19576243081164,
			"y": -138.14111350777773,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 370855519,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 48519057,
			"isDeleted": false,
			"id": "g9OfaOfDJFMPyOasjOMJ6",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 14.888084208155277,
			"y": -120.75650516568032,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 143067921,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 1306224127,
			"isDeleted": false,
			"id": "ZQG0D8cvtKCzYvQdLhs67",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 12.580391900463013,
			"y": -105.37188978106497,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 1871686271,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 477445489,
			"isDeleted": false,
			"id": "TkPDHxxUwjbaW-Eewujdg",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 11.041930362001466,
			"y": -88.44881285798812,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 1383432433,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 2124172831,
			"isDeleted": false,
			"id": "Tvf3Xisu46FgWCvYGvy5v",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 10.27269959277075,
			"y": -73.83342824260347,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 1515455135,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 44984145,
			"isDeleted": false,
			"id": "o9ltvqNvEmsHm8p9eixZv",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 12.580391900463013,
			"y": -49.98727439644961,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 651836113,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 323695167,
			"isDeleted": false,
			"id": "S5EXLY-dDwdO9h3-pGD2R",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 12.580391900463013,
			"y": -39.98727439644961,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 1998083775,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 2145867057,
			"isDeleted": false,
			"id": "9yhFPG3z7nKLRIw7-XD6t",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 11.041930362001466,
			"y": -28.44881285798806,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 1716304049,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 1422430815,
			"isDeleted": false,
			"id": "0KSFGNg1HoOpq1G3oydBI",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 11.811161131232296,
			"y": -16.910351319526512,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 2088576735,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 663193361,
			"isDeleted": false,
			"id": "hTBhKWLqY_k9EBfhdMISC",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 11.811161131232296,
			"y": -9.987274396449607,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 1920236177,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 467988095,
			"isDeleted": false,
			"id": "RvcZA_kEX25tsbimcw4Zf",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 11.811161131232296,
			"y": 3.0896486804734877,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 2031284991,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 872840433,
			"isDeleted": false,
			"id": "mn8cWmmgaCaFRVI0UOGBA",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 13.34962266969373,
			"y": 12.320417911242657,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 201916529,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 1398851231,
			"isDeleted": false,
			"id": "0vElydVrCpz6jqteIKHxD",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 11.041930362001466,
			"y": 26.9358025266273,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 1431976735,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 619427537,
			"isDeleted": false,
			"id": "WROBgvrKtkwiPRPyFc7eE",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 11.041930362001466,
			"y": 40.01272560355039,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 1892797009,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 971807423,
			"isDeleted": false,
			"id": "-TnzKYXejLJYeF6E160Gt",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 11.041930362001466,
			"y": 54.62811021893498,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 365133631,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 483308721,
			"isDeleted": false,
			"id": "apjh_k3xFGZ99pkoIlspo",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 12.580391900463013,
			"y": 68.47426406508885,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 967202865,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 1680403167,
			"isDeleted": false,
			"id": "5b2P0IIK-wgVqNYNG4eC3",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 10.27269959277075,
			"y": 83.8588794497042,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 1554988895,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 2136405649,
			"isDeleted": false,
			"id": "kXT0BUzgSE7UiT1BGk1lJ",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 11.041930362001466,
			"y": 100.78195637278117,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 2020485649,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 2124822271,
			"isDeleted": false,
			"id": "1Oqpz8lNCXC8NGTUVqy22",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 11.811161131232296,
			"y": 110.78195637278117,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 745405311,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 1329331313,
			"isDeleted": false,
			"id": "U0QYiE3r3DiEMRpiQbxgV",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 11.811161131232296,
			"y": 128.47426406508885,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 371245041,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		},
		{
			"type": "line",
			"version": 336,
			"versionNonce": 1340407583,
			"isDeleted": false,
			"id": "uam1AitlJC9O9EqVUffLJ",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 11.041930362001466,
			"y": 138.47426406508885,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 18.461491511418217,
			"height": 1.8461491511418444,
			"seed": 1765815199,
			"groupIds": [
				"9WpRQsjpSMrtR6JLlexa2",
				"a4XdKFh3BKC0bzWTCVECG"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1665801541246,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					18.461491511418217,
					1.8461491511418444
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStrokeSharpness": "sharp",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"currentItemLinearStrokeSharpness": "round",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%