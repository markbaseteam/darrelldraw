---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Her Sins Reached unto heaven ^wIfSGcQo

Heaven ^0gfKFAXQ

BFF
Babylon Is Fallen, Fallen ^5AbXSQkS

My People ^dpEQu7a7

Come Out ^VSnaYlGr

? ^AGmx07zl

Kapan  ^1bsCo5Jv

Legislation  ^524zdWxz

Membuat Undang2 
yg Membatalkan 
Hukum Tuhan ^96gDxtRo

Ada Judgment ^4hpcZ27h

1 AM ^ZzTx5nl2

2nd Coming ^YkEs4jTL

Di tolak ^Wwf2CYBW

BFF ^j12GeKfF

2 AM ^WRf63E04

Summer 1844 ^kdP40bpS

Kemerosotan Moral ^Bme2mOmF

Buat ^yg3KY2Ei

Gereja2
Di USA ^sIlq75o7

Sins belum Reached unto Heaven ^J4sj5Irh

Sins Reached unto heaven ^0RocAI5W

Belum Komplit ^OCpgPgh1

Komplit ^Kb7azQsH

Rev 18:1-5 ^RK1cVowt

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"type": "text",
			"version": 96,
			"versionNonce": 824839482,
			"isDeleted": false,
			"id": "wIfSGcQo",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -289,
			"y": -40.5,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 296,
			"height": 25,
			"seed": 594928102,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "XMz-S6-ts-xQPhlfclNFa",
					"type": "arrow"
				}
			],
			"updated": 1659271105117,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Her Sins Reached unto heaven",
			"rawText": "Her Sins Reached unto heaven",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Her Sins Reached unto heaven"
		},
		{
			"type": "freedraw",
			"version": 79,
			"versionNonce": 987985530,
			"isDeleted": false,
			"id": "ldK6iBgXQ5SXfHG4fwlQa",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -237,
			"y": -200.5,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 239,
			"height": 107,
			"seed": 1969438182,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659270759336,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-30,
					8
				],
				[
					-28,
					16
				],
				[
					-12,
					21
				],
				[
					1,
					24
				],
				[
					20,
					25
				],
				[
					33,
					22
				],
				[
					40,
					17
				],
				[
					43,
					13
				],
				[
					43,
					11
				],
				[
					43,
					9
				],
				[
					38,
					16
				],
				[
					37,
					31
				],
				[
					40,
					34
				],
				[
					52,
					40
				],
				[
					57,
					42
				],
				[
					80,
					45
				],
				[
					91,
					45
				],
				[
					117,
					44
				],
				[
					124,
					41
				],
				[
					129,
					38
				],
				[
					134,
					32
				],
				[
					137,
					26
				],
				[
					137,
					20
				],
				[
					132,
					18
				],
				[
					129,
					29
				],
				[
					131,
					38
				],
				[
					186,
					-16
				],
				[
					182,
					-18
				],
				[
					180,
					-16
				],
				[
					173,
					-52
				],
				[
					125,
					-59
				],
				[
					106,
					-58
				],
				[
					60,
					-42
				],
				[
					57,
					-31
				],
				[
					58,
					-29
				],
				[
					61,
					-28
				],
				[
					69,
					-27
				],
				[
					95,
					-44
				],
				[
					84,
					-50
				],
				[
					70,
					-54
				],
				[
					60,
					-56
				],
				[
					42,
					-59
				],
				[
					17,
					-62
				],
				[
					5,
					-62
				],
				[
					-18,
					-62
				],
				[
					-31,
					-62
				],
				[
					-40,
					-61
				],
				[
					-52,
					-54
				],
				[
					-53,
					-52
				],
				[
					-53,
					-42
				],
				[
					-53,
					-34
				],
				[
					-48,
					-29
				],
				[
					-44,
					-28
				],
				[
					-41,
					-26
				],
				[
					-40,
					-25
				],
				[
					-38,
					-23
				],
				[
					-35,
					-19
				],
				[
					-33,
					-17
				],
				[
					-32,
					-13
				],
				[
					-30,
					-11
				],
				[
					-26,
					-9
				],
				[
					-19,
					-7
				],
				[
					-5,
					-3
				],
				[
					9,
					0
				],
				[
					15,
					-3
				],
				[
					19,
					-6
				],
				[
					20,
					-6
				],
				[
					22,
					-5
				],
				[
					22,
					-4
				],
				[
					24,
					-3
				],
				[
					26,
					-1
				],
				[
					33,
					2
				],
				[
					37,
					2
				],
				[
					37,
					2
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.31640625,
				0.5830078125,
				0.5888671875,
				0.5966796875,
				0.6064453125,
				0.6103515625,
				0.6416015625,
				0.6494140625,
				0.6572265625,
				0.6474609375,
				0.6689453125,
				0.6826171875,
				0.6845703125,
				0.6669921875,
				0.6904296875,
				0.6689453125,
				0.6708984375,
				0.6650390625,
				0.6806640625,
				0.6865234375,
				0.6845703125,
				0.6884765625,
				0.6923828125,
				0.6943359375,
				0.7158203125,
				0.7158203125,
				0.7216796875,
				0.7587890625,
				0.7744140625,
				0.7529296875,
				0.7763671875,
				0.7919921875,
				0.7880859375,
				0.7587890625,
				0.7568359375,
				0.7724609375,
				0.7509765625,
				0.7509765625,
				0.7373046875,
				0.7470703125,
				0.7568359375,
				0.7607421875,
				0.7626953125,
				0.7646484375,
				0.7646484375,
				0.7802734375,
				0.7783203125,
				0.7841796875,
				0.7841796875,
				0.7666015625,
				0.7880859375,
				0.7646484375,
				0.7841796875,
				0.7802734375,
				0.7587890625,
				0.7451171875,
				0.7451171875,
				0.7451171875,
				0.7451171875,
				0.7626953125,
				0.7646484375,
				0.7646484375,
				0.7646484375,
				0.7529296875,
				0.7685546875,
				0.7685546875,
				0.7705078125,
				0.7666015625,
				0.7685546875,
				0.7744140625,
				0.7783203125,
				0.7646484375,
				0.5791015625,
				0.40234375,
				0
			]
		},
		{
			"type": "text",
			"version": 11,
			"versionNonce": 1880147494,
			"isDeleted": false,
			"id": "0gfKFAXQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -196,
			"y": -226.5,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 67,
			"height": 25,
			"seed": 948175206,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659270759336,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Heaven",
			"rawText": "Heaven",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Heaven"
		},
		{
			"type": "arrow",
			"version": 25,
			"versionNonce": 1793234746,
			"isDeleted": false,
			"id": "oG1NCe09Zj7A6zswjhUmt",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -150.62500000000003,
			"y": -57.4375,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 2.5,
			"height": 78.12500000000003,
			"seed": 324449446,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659270759336,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-2.5,
					-78.12500000000003
				]
			]
		},
		{
			"type": "arrow",
			"version": 53,
			"versionNonce": 463540582,
			"isDeleted": false,
			"id": "71qDRBSzap88QUulYlqrf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 26.875,
			"y": -24.625,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 134.16666666666669,
			"height": 2.5,
			"seed": 1343466406,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659270759336,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					134.16666666666669,
					2.5
				]
			]
		},
		{
			"type": "rectangle",
			"version": 282,
			"versionNonce": 1605398074,
			"isDeleted": false,
			"id": "_P4cdREWJO0ks2gUsV5pr",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.977136676807174,
			"x": 230.20833333333337,
			"y": -140.45833333333343,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 87.49999999999997,
			"height": 190.83333333333346,
			"seed": 2091310566,
			"groupIds": [
				"GZLv18DNTEdmuBEsh36U7"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659270769495,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 192,
			"versionNonce": 75508326,
			"isDeleted": false,
			"id": "DZWI7XfWmcRktAelX8lxa",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0.7051033236532005,
			"x": 287.0585664234842,
			"y": -106.077966581114,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 51.66666666666674,
			"height": 41.666666666666686,
			"seed": 1273171706,
			"groupIds": [
				"GZLv18DNTEdmuBEsh36U7"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659270769495,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 191,
			"versionNonce": 582653690,
			"isDeleted": false,
			"id": "q7q9VJRMrbzMy2R-Bb_it",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0.7051033236532005,
			"x": 234.98424531413008,
			"y": -45.71940768372163,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 50.000000000000114,
			"height": 51.666666666666686,
			"seed": 36608186,
			"groupIds": [
				"GZLv18DNTEdmuBEsh36U7"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659270769495,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 92,
			"versionNonce": 1556136742,
			"isDeleted": false,
			"id": "5AbXSQkS",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 323.3333333333335,
			"y": -179.16666666666677,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 242,
			"height": 50,
			"seed": 1830415782,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659270811540,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "BFF\nBabylon Is Fallen, Fallen",
			"rawText": "BFF\nBabylon Is Fallen, Fallen",
			"baseline": 43,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "BFF\nBabylon Is Fallen, Fallen"
		},
		{
			"type": "ellipse",
			"version": 1174,
			"versionNonce": 1151918458,
			"isDeleted": false,
			"id": "cV6SyhCScBt5mUitvQi6V",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 500.44706469131506,
			"y": -20.810244820837738,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 21.772341217745836,
			"height": 40.619719089085095,
			"seed": 2065142522,
			"groupIds": [
				"ZAXevCcyyg3uwOVTuRGjk"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659270856020,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1191,
			"versionNonce": 1609272102,
			"isDeleted": false,
			"id": "fibN-fGz0g6Rni37DdQ9j",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 458.0404644808018,
			"y": -21.595552232143632,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 21.772341217745836,
			"height": 40.619719089085095,
			"seed": 303739302,
			"groupIds": [
				"ZAXevCcyyg3uwOVTuRGjk"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659270856020,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1053,
			"versionNonce": 247636538,
			"isDeleted": false,
			"id": "hgC_Ni33XZYYLUSX_X2-A",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 426.23551432291674,
			"y": -55.7564246239462,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 100.30308234832611,
			"height": 53.18463766997794,
			"seed": 928981946,
			"groupIds": [
				"ZAXevCcyyg3uwOVTuRGjk"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659270856020,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 943,
			"versionNonce": 769341030,
			"isDeleted": false,
			"id": "bMOkVze686gTsuoN-x1FT",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 500.054410985662,
			"y": -71.46257285006197,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 50.043408024754726,
			"height": 31.98133756472127,
			"seed": 1281461478,
			"groupIds": [
				"ZAXevCcyyg3uwOVTuRGjk"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659270856020,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1084,
			"versionNonce": 426134266,
			"isDeleted": false,
			"id": "CY0vB_0dM8dzeqpZ7fXoX",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 430.16205137944576,
			"y": -21.202898526490685,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 21.772341217745836,
			"height": 40.619719089085095,
			"seed": 1308007546,
			"groupIds": [
				"ZAXevCcyyg3uwOVTuRGjk"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659270856020,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1148,
			"versionNonce": 1328773542,
			"isDeleted": false,
			"id": "3AHpRWOm6Pi1LTk2IifgP",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 481.5996868199758,
			"y": -17.669015175614504,
			"strokeColor": "#000000",
			"backgroundColor": "white",
			"width": 21.772341217745836,
			"height": 40.619719089085095,
			"seed": 665518118,
			"groupIds": [
				"ZAXevCcyyg3uwOVTuRGjk"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659270856020,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 30,
			"versionNonce": 1583859942,
			"isDeleted": false,
			"id": "dpEQu7a7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 425.66666666666674,
			"y": 28.394551569720534,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 97,
			"height": 25,
			"seed": 186047418,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659270867689,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "My People",
			"rawText": "My People",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "My People"
		},
		{
			"type": "arrow",
			"version": 124,
			"versionNonce": 1579625830,
			"isDeleted": false,
			"id": "IliICZj1Nn-UVEXQwYivC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 408.8462644523703,
			"y": 70.08768678952154,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 244.82040221429645,
			"height": 3.3068647801989925,
			"seed": 773587258,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659270894960,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					244.82040221429645,
					3.3068647801989925
				]
			]
		},
		{
			"type": "text",
			"version": 153,
			"versionNonce": 280231590,
			"isDeleted": false,
			"id": "VSnaYlGr",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 441,
			"y": 88,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 156,
			"height": 41,
			"seed": 1632101542,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659270898319,
			"link": null,
			"locked": false,
			"fontSize": 32.79999999999999,
			"fontFamily": 1,
			"text": "Come Out",
			"rawText": "Come Out",
			"baseline": 29,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Come Out"
		},
		{
			"type": "freedraw",
			"version": 5,
			"versionNonce": 1218817510,
			"isDeleted": false,
			"id": "o7lgCTW2Qmgd9yzBmI0mX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -59.751265474625995,
			"y": -105.08333333333371,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 6.666666666666629,
			"height": 0,
			"seed": 1064423270,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659270943870,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-6.666666666666629,
					0
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.33984375,
				0.349609375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 5,
			"versionNonce": 947647738,
			"isDeleted": false,
			"id": "GfxSR_juj3uoVodoLqoDR",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 355.80429008092955,
			"y": -8.416666666667027,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 3.3333333333333144,
			"seed": 1078004602,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659270946241,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-3.3333333333333144
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.326171875,
				0.11328125,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 5,
			"versionNonce": 429800998,
			"isDeleted": false,
			"id": "PYht8njLc5W0ZOWpty_eg",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 559.1376234142629,
			"y": 13.805555555555202,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 1.1111111111110858,
			"height": 2.2222222222222285,
			"seed": 354774950,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659270947552,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-1.1111111111110858,
					-2.2222222222222285
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.435546875,
				0.17578125,
				0
			]
		},
		{
			"type": "line",
			"version": 57,
			"versionNonce": 137634874,
			"isDeleted": false,
			"id": "I13O5AoUN_VIr8wBdeZoC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -164.19570991907096,
			"y": 0.47222222222239907,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 1.1111111111110858,
			"height": 130,
			"seed": 84451130,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659271052069,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.1111111111110858,
					130
				]
			]
		},
		{
			"type": "text",
			"version": 103,
			"versionNonce": 1352516070,
			"isDeleted": false,
			"id": "AGmx07zl",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -210.8623765857376,
			"y": 31.75000000000007,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 26,
			"height": 68,
			"seed": 1606079590,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659271112141,
			"link": null,
			"locked": false,
			"fontSize": 53.77777777777783,
			"fontFamily": 1,
			"text": "?",
			"rawText": "?",
			"baseline": 48,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "?"
		},
		{
			"type": "text",
			"version": 46,
			"versionNonce": 1602710394,
			"isDeleted": false,
			"id": "1bsCo5Jv",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -305.30682103018216,
			"y": 64.47222222222237,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 69,
			"height": 25,
			"seed": 2003047546,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "XMz-S6-ts-xQPhlfclNFa",
					"type": "arrow"
				}
			],
			"updated": 1659271109677,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Kapan ",
			"rawText": "Kapan ",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Kapan "
		},
		{
			"type": "arrow",
			"version": 39,
			"versionNonce": 557837370,
			"isDeleted": false,
			"id": "XMz-S6-ts-xQPhlfclNFa",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -282.59978330611887,
			"y": 52.69444444444465,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 28.96436071817857,
			"height": 60.00000000000002,
			"seed": 1911471354,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659271109678,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "1bsCo5Jv",
				"focus": -0.5821217016693567,
				"gap": 11.777777777777715
			},
			"endBinding": {
				"elementId": "wIfSGcQo",
				"focus": 0.6663804022734301,
				"gap": 8.194444444444628
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					28.96436071817857,
					-60.00000000000002
				]
			]
		},
		{
			"type": "text",
			"version": 32,
			"versionNonce": 868774310,
			"isDeleted": false,
			"id": "524zdWxz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -275.30682103018216,
			"y": 152.58333333333354,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 114,
			"height": 25,
			"seed": 1120090170,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "PozkgT_7qPU056XEgCyrQ",
					"type": "arrow"
				}
			],
			"updated": 1659271158791,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Legislation ",
			"rawText": "Legislation ",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Legislation "
		},
		{
			"type": "arrow",
			"version": 52,
			"versionNonce": 2027634662,
			"isDeleted": false,
			"id": "PozkgT_7qPU056XEgCyrQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -155.30682103018216,
			"y": 167.1773451180468,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 71.11111111111121,
			"height": 1.2267673093867586,
			"seed": 84274426,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659271196715,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "524zdWxz",
				"focus": 0.23647488993358448,
				"gap": 6
			},
			"endBinding": {
				"elementId": "96gDxtRo",
				"focus": 0.20763760049474367,
				"gap": 8.8888888888888
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					71.11111111111121,
					-1.2267673093867586
				]
			]
		},
		{
			"type": "text",
			"version": 82,
			"versionNonce": 1619969190,
			"isDeleted": false,
			"id": "96gDxtRo",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -75.30682103018216,
			"y": 134.80555555555583,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 187,
			"height": 75,
			"seed": 544039866,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "PozkgT_7qPU056XEgCyrQ",
					"type": "arrow"
				}
			],
			"updated": 1659271196714,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Membuat Undang2 \nyg Membatalkan \nHukum Tuhan",
			"rawText": "Membuat Undang2 \nyg Membatalkan \nHukum Tuhan",
			"baseline": 68,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Membuat Undang2 \nyg Membatalkan \nHukum Tuhan"
		},
		{
			"type": "rectangle",
			"version": 108,
			"versionNonce": 1698860922,
			"isDeleted": false,
			"id": "V9UgG_CGYJr_1Kz4vj1kW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 174.84900482671807,
			"y": 326.691408368824,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 75.32569009160352,
			"height": 50.447480520064744,
			"seed": 1671265830,
			"groupIds": [
				"zJSC3TZIyUFO9Qys6yJXc"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659271252854,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 92,
			"versionNonce": 1904983334,
			"isDeleted": false,
			"id": "FxQ8DKXi6su-9hOZTGBtK",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 173.58206785870647,
			"y": 327.08743553535277,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 36.62625298032098,
			"height": 26.95139370250032,
			"seed": 1426301094,
			"groupIds": [
				"zJSC3TZIyUFO9Qys6yJXc"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659271252854,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					36.62625298032098,
					26.95139370250032
				]
			]
		},
		{
			"type": "line",
			"version": 123,
			"versionNonce": 200708154,
			"isDeleted": false,
			"id": "lHbEHS45awwJqpDXCQwhu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 250.66929137510527,
			"y": 327.3190776995941,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 43.53686675019289,
			"height": 26.951393702500344,
			"seed": 1938172198,
			"groupIds": [
				"zJSC3TZIyUFO9Qys6yJXc"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659271252854,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-43.53686675019289,
					26.951393702500344
				]
			]
		},
		{
			"type": "text",
			"version": 14,
			"versionNonce": 379008570,
			"isDeleted": false,
			"id": "4hpcZ27h",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 282.4709567475952,
			"y": 335.91666666666663,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 139,
			"height": 25,
			"seed": 401550246,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659271268772,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Ada Judgment",
			"rawText": "Ada Judgment",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Ada Judgment"
		},
		{
			"type": "arrow",
			"version": 25,
			"versionNonce": 111688038,
			"isDeleted": false,
			"id": "Np72cFegnxmy_1fYKTF43",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 535.8042900809286,
			"y": 344.91666666666663,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 94.44444444444446,
			"height": 3.3333333333333144,
			"seed": 709485158,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659271299545,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-94.44444444444446,
					3.3333333333333144
				]
			]
		},
		{
			"type": "text",
			"version": 18,
			"versionNonce": 1772394150,
			"isDeleted": false,
			"id": "ZzTx5nl2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 574.6931789698175,
			"y": 332.5833333333333,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 45,
			"height": 25,
			"seed": 1109325818,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659271313204,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "1 AM",
			"rawText": "1 AM",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "1 AM"
		},
		{
			"type": "text",
			"version": 28,
			"versionNonce": 1012831418,
			"isDeleted": false,
			"id": "YkEs4jTL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 298.15087956583784,
			"y": 364.4305555555555,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 106,
			"height": 25,
			"seed": 1647285286,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "kCtOL76YijruYAup_kWwM",
					"type": "arrow"
				}
			],
			"updated": 1659271378836,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "2nd Coming",
			"rawText": "2nd Coming",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "2nd Coming"
		},
		{
			"type": "arrow",
			"version": 91,
			"versionNonce": 1504437030,
			"isDeleted": false,
			"id": "kCtOL76YijruYAup_kWwM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 309.6058522027214,
			"y": 432.0416666666667,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 21.917148957188772,
			"height": 36.388888888888914,
			"seed": 440243322,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659272195398,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "Wwf2CYBW",
				"focus": 0.4005690799873538,
				"gap": 11.000000000000057
			},
			"endBinding": {
				"elementId": "YkEs4jTL",
				"focus": 0.13797436541844543,
				"gap": 6.222222222222285
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					21.917148957188772,
					-36.388888888888914
				]
			]
		},
		{
			"type": "text",
			"version": 43,
			"versionNonce": 1624970810,
			"isDeleted": false,
			"id": "Wwf2CYBW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 204.81754623250455,
			"y": 443.04166666666674,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 118,
			"height": 37,
			"seed": 1138748794,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "kCtOL76YijruYAup_kWwM",
					"type": "arrow"
				},
				{
					"id": "jgXdJt6iz16jn-uRNRLZp",
					"type": "arrow"
				}
			],
			"updated": 1659272199935,
			"link": null,
			"locked": false,
			"fontSize": 28.888888888888932,
			"fontFamily": 1,
			"text": "Di tolak",
			"rawText": "Di tolak",
			"baseline": 26,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Di tolak"
		},
		{
			"type": "arrow",
			"version": 190,
			"versionNonce": 787339046,
			"isDeleted": false,
			"id": "jgXdJt6iz16jn-uRNRLZp",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 332.5462504900531,
			"y": 461.6204922120604,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 150.9477278543091,
			"height": 5.002619733583288,
			"seed": 1966239974,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659272199935,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "Wwf2CYBW",
				"focus": 0.11520664113449118,
				"gap": 9.728704257548529
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					150.9477278543091,
					-5.002619733583288
				]
			]
		},
		{
			"type": "text",
			"version": 26,
			"versionNonce": 242215930,
			"isDeleted": false,
			"id": "j12GeKfF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 502.8175462325047,
			"y": 420.43055555555554,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 70,
			"height": 47,
			"seed": 905554278,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659271434393,
			"link": null,
			"locked": false,
			"fontSize": 36.923076923076906,
			"fontFamily": 1,
			"text": "BFF",
			"rawText": "BFF",
			"baseline": 33,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "BFF"
		},
		{
			"type": "ellipse",
			"version": 32,
			"versionNonce": 1654040762,
			"isDeleted": false,
			"id": "5KIIfpuJmehRwHRtzPZhw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 548.8175462325045,
			"y": 313.27083333333337,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 90,
			"height": 63,
			"seed": 172516326,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659271463192,
			"link": null,
			"locked": false
		},
		{
			"type": "arrow",
			"version": 35,
			"versionNonce": 1765666106,
			"isDeleted": false,
			"id": "kFCVRbKF4Dr5FbqxjpctN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 680.8363296129216,
			"y": 443.82372517709933,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 82.01878338041718,
			"height": 0.5528918437659627,
			"seed": 1232814650,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659271483396,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "WRf63E04",
				"focus": -0.10374270000098833,
				"gap": 11.981216619582824
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-82.01878338041718,
					-0.5528918437659627
				]
			]
		},
		{
			"type": "text",
			"version": 35,
			"versionNonce": 1137580902,
			"isDeleted": false,
			"id": "WRf63E04",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 692.8175462325045,
			"y": 430.27083333333337,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 54,
			"height": 25,
			"seed": 401460646,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "kFCVRbKF4Dr5FbqxjpctN",
					"type": "arrow"
				}
			],
			"updated": 1659271483398,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "2 AM",
			"rawText": "2 AM",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "2 AM"
		},
		{
			"type": "ellipse",
			"version": 55,
			"versionNonce": 223127974,
			"isDeleted": false,
			"id": "AmfKF_2Zyv3ieTEAdPRRz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 678.8175462325045,
			"y": 411.27083333333337,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 92,
			"height": 59,
			"seed": 830170810,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659271490363,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 79,
			"versionNonce": 1768459046,
			"isDeleted": false,
			"id": "kdP40bpS",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 330.81754623250447,
			"y": 265.7073412698413,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 148,
			"height": 30,
			"seed": 1176678182,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659271525301,
			"link": null,
			"locked": false,
			"fontSize": 23.650793650793652,
			"fontFamily": 1,
			"text": "Summer 1844",
			"rawText": "Summer 1844",
			"baseline": 21,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Summer 1844"
		},
		{
			"type": "text",
			"version": 91,
			"versionNonce": 1708436666,
			"isDeleted": false,
			"id": "Bme2mOmF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 439.00536260116115,
			"y": 474.14583333333337,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 212,
			"height": 28,
			"seed": 863089126,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659272216629,
			"link": null,
			"locked": false,
			"fontSize": 22.652406417112314,
			"fontFamily": 1,
			"text": "Kemerosotan Moral",
			"rawText": "Kemerosotan Moral",
			"baseline": 20,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Kemerosotan Moral"
		},
		{
			"type": "arrow",
			"version": 17,
			"versionNonce": 894050086,
			"isDeleted": false,
			"id": "RU6EIahHJyjcL3TGW6w7k",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 499.00536260116115,
			"y": 274.39583333333337,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 163.74999999999994,
			"height": 2.5,
			"seed": 2113807654,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659272044901,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					163.74999999999994,
					2.5
				]
			]
		},
		{
			"type": "text",
			"version": 14,
			"versionNonce": 231463290,
			"isDeleted": false,
			"id": "yg3KY2Ei",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 551.5053626011611,
			"y": 241.64583333333337,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 52,
			"height": 25,
			"seed": 544569082,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659272054369,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Buat",
			"rawText": "Buat",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Buat"
		},
		{
			"type": "text",
			"version": 69,
			"versionNonce": 948978534,
			"isDeleted": false,
			"id": "sIlq75o7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 686.5053626011611,
			"y": 242.89583333333337,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 109,
			"height": 68,
			"seed": 684104250,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659272077283,
			"link": null,
			"locked": false,
			"fontSize": 26.999999999999993,
			"fontFamily": 1,
			"text": "Gereja2\nDi USA",
			"rawText": "Gereja2\nDi USA",
			"baseline": 58,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Gereja2\nDi USA"
		},
		{
			"type": "line",
			"version": 63,
			"versionNonce": 1436739514,
			"isDeleted": false,
			"id": "xkLauGvX6UVNTNfI6guDI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 252.59927078548944,
			"y": 488.57291666666674,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 1.175772227207176,
			"height": 39.918820481309695,
			"seed": 588432806,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659272208961,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.175772227207176,
					39.918820481309695
				]
			]
		},
		{
			"type": "line",
			"version": 51,
			"versionNonce": 1327388986,
			"isDeleted": false,
			"id": "2z-CXvkvZ9atygMyh84b_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 538.8492707854895,
			"y": 513.5729166666667,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 1.25,
			"height": 32.5,
			"seed": 2016151782,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1659272218824,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.25,
					32.5
				]
			]
		},
		{
			"type": "text",
			"version": 62,
			"versionNonce": 2069943034,
			"isDeleted": false,
			"id": "J4sj5Irh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 85.2778422140608,
			"y": 545.8229166666667,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 317,
			"height": 25,
			"seed": 2071621478,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659272302592,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Sins belum Reached unto Heaven",
			"rawText": "Sins belum Reached unto Heaven",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Sins belum Reached unto Heaven"
		},
		{
			"type": "text",
			"version": 34,
			"versionNonce": 1464516838,
			"isDeleted": false,
			"id": "0RocAI5W",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 487.9564136426321,
			"y": 551.5900297619049,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 256,
			"height": 25,
			"seed": 1551918010,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1659272332604,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Sins Reached unto heaven",
			"rawText": "Sins Reached unto heaven",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Sins Reached unto heaven"
		},
		{
			"id": "VMNPsl_t4EB04T24rrZ0D",
			"type": "line",
			"x": 223.67069935691805,
			"y": 582.0450148809525,
			"width": 0,
			"height": 31.42857142857133,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1156446566,
			"version": 38,
			"versionNonce": 1268764026,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1659272376276,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					31.42857142857133
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "WVcnj4GFtmgtrHAOvLDOt",
			"type": "line",
			"x": 585.0992707854895,
			"y": 586.3307291666669,
			"width": 2.721769460052883,
			"height": 28.791716151471633,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 422141734,
			"version": 39,
			"versionNonce": 1388675322,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1659272436220,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-2.721769460052883,
					28.791716151471633
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "OCpgPgh1",
			"type": "text",
			"x": 169.38498507120377,
			"y": 625.9021577380953,
			"width": 133,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 530401958,
			"version": 32,
			"versionNonce": 1563537318,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1659272422867,
			"link": null,
			"locked": false,
			"text": "Belum Komplit",
			"rawText": "Belum Komplit",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": "Belum Komplit"
		},
		{
			"id": "Kb7azQsH",
			"type": "text",
			"x": 556.5278422140609,
			"y": 615.9021577380953,
			"width": 68,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 454397990,
			"version": 40,
			"versionNonce": 935370918,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1659272437994,
			"link": null,
			"locked": false,
			"text": "Komplit",
			"rawText": "Komplit",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": "Komplit"
		},
		{
			"id": "RK1cVowt",
			"type": "text",
			"x": 763.6706993569182,
			"y": 567.3307291666669,
			"width": 186,
			"height": 48,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"seed": 955448698,
			"version": 56,
			"versionNonce": 1946172602,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1659272489761,
			"link": null,
			"locked": false,
			"text": "Rev 18:1-5",
			"rawText": "Rev 18:1-5",
			"fontSize": 38.2857142857143,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 34,
			"containerId": null,
			"originalText": "Rev 18:1-5"
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStrokeSharpness": "sharp",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"currentItemLinearStrokeSharpness": "round",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%