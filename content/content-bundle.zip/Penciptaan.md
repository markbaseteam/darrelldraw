---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Exerchomai ^VeerUrub

Bapa ^UACn6zdC

Anak ^Qe6ahOrF

Anak ^5wSZ7qWe

Let there be Light ^PuFdnDuk

Bapa ^oPj1GSwR

Anak ^JZ84togs

Bapa ^FLlw1Gj4

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"id": "StRZVFpp0cXe7Y1MgHNB2",
			"type": "rectangle",
			"x": -458.6900641749048,
			"y": -240.29245297150433,
			"width": 1098.8346066682236,
			"height": 536.60870228643,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "#000",
			"fillStyle": "solid",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"DDIDib860CLN20xXouQt5"
			],
			"strokeSharpness": "round",
			"seed": 1257753715,
			"version": 1480,
			"versionNonce": 1461841203,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1666152506543,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 6418,
			"versionNonce": 371520381,
			"isDeleted": false,
			"id": "mGjwFW7qy4nrey2HQluo7",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 12.004601189511277,
			"x": -205.43030018954454,
			"y": -127.33379823170785,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 11.538622885462923,
			"height": 60.95907995700587,
			"seed": 1598109917,
			"groupIds": [
				"M76jsr77am77u_XKTTcc1",
				"DDIDib860CLN20xXouQt5"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1666152506543,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					11.537045160358337,
					53.97696352292202
				],
				[
					-0.001577725104584837,
					60.95907995700587
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 6807,
			"versionNonce": 24366803,
			"isDeleted": false,
			"id": "l5MSVxDlaboR5p0qIvtu3",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.986741481222998,
			"x": -251.30062961739742,
			"y": -123.72237496424012,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 14.452758388892958,
			"height": 62.48104038979949,
			"seed": 456200051,
			"groupIds": [
				"M76jsr77am77u_XKTTcc1",
				"DDIDib860CLN20xXouQt5"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1666152506543,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					14.319664682160473,
					62.48104038979949
				],
				[
					-0.13309370673248533,
					54.63343918654641
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 7375,
			"versionNonce": 1536392157,
			"isDeleted": false,
			"id": "CQUCYtvpNZ7QEmx84pqUD",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.269319433247224,
			"x": -226.9349063237127,
			"y": -144.60961133776655,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 83.52714890218448,
			"height": 133.03626946559814,
			"seed": 935335229,
			"groupIds": [
				"oFvBBUfqP6OLeOiGzaNbJ",
				"M76jsr77am77u_XKTTcc1",
				"DDIDib860CLN20xXouQt5"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1666152506543,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					44.613958784280584,
					132.23863830903306
				],
				[
					-38.9131901179039,
					131.21062826699597
				],
				[
					0.00008114047522342619,
					-0.7976311565650853
				]
			]
		},
		{
			"type": "ellipse",
			"version": 6125,
			"versionNonce": 1985510515,
			"isDeleted": false,
			"id": "8fJ-eRAXfKVY3TiICsWID",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.269319433247224,
			"x": -253.7859484656172,
			"y": -174.11983135134014,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 53.17622184242456,
			"height": 51.84683658148277,
			"seed": 870623507,
			"groupIds": [
				"oFvBBUfqP6OLeOiGzaNbJ",
				"M76jsr77am77u_XKTTcc1",
				"DDIDib860CLN20xXouQt5"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1666152506543,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 6541,
			"versionNonce": 382859325,
			"isDeleted": false,
			"id": "0-WouYxpQPbhWLk4yOEba",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 12.004601189511277,
			"x": 310.876359151041,
			"y": -115.68620516775974,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 11.538622885462923,
			"height": 60.95907995700587,
			"seed": 1008094909,
			"groupIds": [
				"P00jZC5dif81UCxcgyShn",
				"DDIDib860CLN20xXouQt5"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1666152506544,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					11.537045160358337,
					53.97696352292202
				],
				[
					-0.001577725104584837,
					60.95907995700587
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 6930,
			"versionNonce": 1905686035,
			"isDeleted": false,
			"id": "nZSXZB5LjyggukVCFuQnw",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.986741481222998,
			"x": 265.00602972318813,
			"y": -112.07478190029201,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 14.452758388892958,
			"height": 62.48104038979949,
			"seed": 1917372307,
			"groupIds": [
				"P00jZC5dif81UCxcgyShn",
				"DDIDib860CLN20xXouQt5"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1666152506544,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					14.319664682160473,
					62.48104038979949
				],
				[
					-0.13309370673248533,
					54.63343918654641
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 7498,
			"versionNonce": 1908533405,
			"isDeleted": false,
			"id": "QfTXw_0o2TtZ6QNtpV0Tv",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.269319433247224,
			"x": 289.37175301687284,
			"y": -132.96201827381844,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 83.52714890218448,
			"height": 133.03626946559814,
			"seed": 1228369693,
			"groupIds": [
				"4S2wT5SmKY8m9rXKBtepi",
				"P00jZC5dif81UCxcgyShn",
				"DDIDib860CLN20xXouQt5"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1666152506544,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					44.613958784280584,
					132.23863830903306
				],
				[
					-38.9131901179039,
					131.21062826699597
				],
				[
					0.00008114047522342619,
					-0.7976311565650853
				]
			]
		},
		{
			"type": "ellipse",
			"version": 6248,
			"versionNonce": 1914977203,
			"isDeleted": false,
			"id": "OMZogAYaCTvCBcwCSb0vS",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.269319433247224,
			"x": 262.52071087496836,
			"y": -162.47223828739203,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 53.17622184242456,
			"height": 51.84683658148277,
			"seed": 462445875,
			"groupIds": [
				"4S2wT5SmKY8m9rXKBtepi",
				"P00jZC5dif81UCxcgyShn",
				"DDIDib860CLN20xXouQt5"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1666152506544,
			"link": null,
			"locked": false
		},
		{
			"id": "XNKWKT5Bq45dLKVtHUo9A",
			"type": "line",
			"x": -461.1366335871014,
			"y": 122.62246636013131,
			"width": 1096.6957158627715,
			"height": 57.391304347826065,
			"angle": 0,
			"strokeColor": "#0000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"DDIDib860CLN20xXouQt5"
			],
			"strokeSharpness": "round",
			"seed": 49807475,
			"version": 467,
			"versionNonce": 1578421501,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1666152506544,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					93.91304347826087,
					-21.913054093070627
				],
				[
					249.39129373301625,
					-3.130466627038061
				],
				[
					440.347847316576,
					-20.86956521739131
				],
				[
					684.5218028192934,
					-57.391304347826065
				],
				[
					813.9130434782608,
					-37.565228006114125
				],
				[
					972.5217603600543,
					-15.652173913043441
				],
				[
					1047.6522163722825,
					-37.565228006114125
				],
				[
					1096.6957158627715,
					-34.434814453125
				]
			],
			"lastCommittedPoint": [
				1096.6957158627715,
				-34.434814453125
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "fhWKfMqibV-gQghnILUFz",
			"type": "line",
			"x": -461.1366335871014,
			"y": 125.97245563358666,
			"width": 1097.7391782014265,
			"height": 210.78262992527175,
			"angle": 0,
			"strokeColor": "blue",
			"backgroundColor": "blue",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"DDIDib860CLN20xXouQt5"
			],
			"strokeSharpness": "round",
			"seed": 382231517,
			"version": 1211,
			"versionNonce": 1411927379,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1666152506544,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					73.04347826086956,
					-21.91300101902175
				],
				[
					270.260885487432,
					-4.173902428668498
				],
				[
					541.5652333135189,
					-16.695609714673935
				],
				[
					779.4783086362091,
					-44.86954398777175
				],
				[
					964.1739820397418,
					-8.34780485733694
				],
				[
					1061.2174390709918,
					-1.0434358016304373
				],
				[
					1097.7391782014265,
					-1.0434358016304373
				],
				[
					1092.521680748981,
					89.73914104959226
				],
				[
					1062.26098102072,
					137.73915166440213
				],
				[
					1000.6957211701763,
					163.82616126019013
				],
				[
					776.34789508322,
					164.86959706182063
				],
				[
					312.00001592221463,
					165.9130859375
				],
				[
					111.65216860563856,
					165.9130859375
				],
				[
					59.47825556216026,
					153.39132557744563
				],
				[
					26.086956521739125,
					126.26093325407612
				],
				[
					7.30434251868212,
					82.43482506793464
				],
				[
					3.1304135529890686,
					38.60876995584243
				],
				[
					2.086951214334192,
					-1.0434888756793725
				]
			],
			"lastCommittedPoint": [
				0,
				1.0434888756793725
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "Kgjy2RsWymST1PKR0yVP_",
			"type": "arrow",
			"x": -154.8898644640633,
			"y": -85.02975001215103,
			"width": 376.18794979679933,
			"height": 38.608723516049565,
			"angle": 0,
			"strokeColor": "white",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"DDIDib860CLN20xXouQt5"
			],
			"strokeSharpness": "round",
			"seed": 890851475,
			"version": 925,
			"versionNonce": 457975133,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1666152506544,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					185.75322026215252,
					-38.608723516049565
				],
				[
					376.18794979679933,
					-4.173942234205157
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "VeerUrub",
			"type": "text",
			"x": -96.64963938278714,
			"y": -95.60578795015508,
			"width": 257.8260975713316,
			"height": 61.76220022207144,
			"angle": 0,
			"strokeColor": "white",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"DDIDib860CLN20xXouQt5"
			],
			"strokeSharpness": "round",
			"seed": 1062862333,
			"version": 1052,
			"versionNonce": 720972531,
			"isDeleted": false,
			"boundElements": [],
			"updated": 1666152506544,
			"link": null,
			"locked": false,
			"text": "Exerchomai",
			"rawText": "Exerchomai",
			"fontSize": 48.709656139671424,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 43.76220022207144,
			"containerId": null,
			"originalText": "Exerchomai"
		},
		{
			"id": "UACn6zdC",
			"type": "text",
			"x": -263.9192528975627,
			"y": -1.4427908367094062,
			"width": 72,
			"height": 36,
			"angle": 0,
			"strokeColor": "white",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"DDIDib860CLN20xXouQt5"
			],
			"strokeSharpness": "round",
			"seed": 1532857267,
			"version": 206,
			"versionNonce": 2092528061,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1666152506545,
			"link": null,
			"locked": false,
			"text": "Bapa",
			"rawText": "Bapa",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 25,
			"containerId": null,
			"originalText": "Bapa"
		},
		{
			"id": "Qe6ahOrF",
			"type": "text",
			"x": 256.77633558749136,
			"y": 6.905014020627419,
			"width": 65,
			"height": 36,
			"angle": 0,
			"strokeColor": "white",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"DDIDib860CLN20xXouQt5"
			],
			"strokeSharpness": "round",
			"seed": 823698579,
			"version": 244,
			"versionNonce": 1528648851,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1666152506545,
			"link": null,
			"locked": false,
			"text": "Anak",
			"rawText": "Anak",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 25,
			"containerId": null,
			"originalText": "Anak"
		},
		{
			"id": "ekgAaC1sbvqynabL3dP3w",
			"type": "rectangle",
			"x": 697.373221251184,
			"y": -244.56601736038186,
			"width": 1098.8346066682236,
			"height": 536.60870228643,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "#000",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"Opo68bMQjV3obn2ocdD05",
				"Yut6WcS8op42bUmZkZxMx"
			],
			"strokeSharpness": "round",
			"seed": 143615965,
			"version": 2178,
			"versionNonce": 1870541341,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1666152506545,
			"link": null,
			"locked": false
		},
		{
			"id": "JkGsZGKX7s_bD4g2xQNQd",
			"type": "line",
			"x": 695.8106770111709,
			"y": 125.8674430410704,
			"width": 1097.7391782014265,
			"height": 210.78262992527175,
			"angle": 0,
			"strokeColor": "blue",
			"backgroundColor": "blue",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"Opo68bMQjV3obn2ocdD05",
				"Yut6WcS8op42bUmZkZxMx"
			],
			"strokeSharpness": "round",
			"seed": 416317395,
			"version": 1929,
			"versionNonce": 1951091251,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1666152506545,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					73.04347826086956,
					-21.91300101902175
				],
				[
					270.260885487432,
					-4.173902428668498
				],
				[
					541.5652333135189,
					-16.695609714673935
				],
				[
					779.4783086362091,
					-44.86954398777175
				],
				[
					964.1739820397418,
					-8.34780485733694
				],
				[
					1061.2174390709918,
					-1.0434358016304373
				],
				[
					1097.7391782014265,
					-1.0434358016304373
				],
				[
					1092.521680748981,
					89.73914104959226
				],
				[
					1062.26098102072,
					137.73915166440213
				],
				[
					1000.6957211701763,
					163.82616126019013
				],
				[
					776.34789508322,
					164.86959706182063
				],
				[
					312.00001592221463,
					165.9130859375
				],
				[
					111.65216860563856,
					165.9130859375
				],
				[
					59.47825556216026,
					153.39132557744563
				],
				[
					26.086956521739125,
					126.26093325407612
				],
				[
					7.30434251868212,
					82.43482506793464
				],
				[
					3.1304135529890686,
					38.60876995584243
				],
				[
					2.086951214334192,
					-1.0434888756793725
				]
			],
			"lastCommittedPoint": [
				0,
				1.0434888756793725
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"type": "line",
			"version": 7497,
			"versionNonce": 1082910333,
			"isDeleted": false,
			"id": "P5wSPAxVo0vzgdlxYsXHJ",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 12.004601189511277,
			"x": 924.6960969857984,
			"y": -126.51200003289898,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 11.538622885462923,
			"height": 60.95907995700587,
			"seed": 780658749,
			"groupIds": [
				"IjvgSEE-Tf9MlYceNb-hG",
				"ONmPh10Zmt91k42rAgsGQ",
				"YWO-opB3X9utpr8SMx_oP",
				"Yut6WcS8op42bUmZkZxMx"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1666152506545,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					11.537045160358337,
					53.97696352292202
				],
				[
					-0.001577725104584837,
					60.95907995700587
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 7886,
			"versionNonce": 1265208275,
			"isDeleted": false,
			"id": "SAMQkmsWiD8hIBdGt1m1C",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.986741481222998,
			"x": 878.8257675579453,
			"y": -122.90057676543125,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 14.452758388892958,
			"height": 62.48104038979949,
			"seed": 1282901523,
			"groupIds": [
				"IjvgSEE-Tf9MlYceNb-hG",
				"ONmPh10Zmt91k42rAgsGQ",
				"YWO-opB3X9utpr8SMx_oP",
				"Yut6WcS8op42bUmZkZxMx"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1666152506545,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					14.319664682160473,
					62.48104038979949
				],
				[
					-0.13309370673248533,
					54.63343918654641
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 8454,
			"versionNonce": 581177053,
			"isDeleted": false,
			"id": "bNHK7LQxMnKtZXnkQRTKj",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.269319433247224,
			"x": 903.1914908516301,
			"y": -143.7878131389577,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 83.52714890218448,
			"height": 133.03626946559814,
			"seed": 2100943005,
			"groupIds": [
				"Jr0UnbL1wXc91nuRXVkrd",
				"IjvgSEE-Tf9MlYceNb-hG",
				"ONmPh10Zmt91k42rAgsGQ",
				"YWO-opB3X9utpr8SMx_oP",
				"Yut6WcS8op42bUmZkZxMx"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1666152506545,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					44.613958784280584,
					132.23863830903306
				],
				[
					-38.9131901179039,
					131.21062826699597
				],
				[
					0.00008114047522342619,
					-0.7976311565650853
				]
			]
		},
		{
			"type": "ellipse",
			"version": 7204,
			"versionNonce": 1418631539,
			"isDeleted": false,
			"id": "u3akDEUVn6ueUDLb73k_i",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.269319433247224,
			"x": 876.3404487097255,
			"y": -173.29803315253127,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 53.17622184242456,
			"height": 51.84683658148277,
			"seed": 1852001203,
			"groupIds": [
				"Jr0UnbL1wXc91nuRXVkrd",
				"IjvgSEE-Tf9MlYceNb-hG",
				"ONmPh10Zmt91k42rAgsGQ",
				"YWO-opB3X9utpr8SMx_oP",
				"Yut6WcS8op42bUmZkZxMx"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1666152506545,
			"link": null,
			"locked": false
		},
		{
			"id": "5wSZ7qWe",
			"type": "text",
			"x": 863.5887132692684,
			"y": -3.6249739692738103,
			"width": 83,
			"height": 46,
			"angle": 0,
			"strokeColor": "white",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"ONmPh10Zmt91k42rAgsGQ",
				"YWO-opB3X9utpr8SMx_oP",
				"Yut6WcS8op42bUmZkZxMx"
			],
			"strokeSharpness": "round",
			"seed": 1993576403,
			"version": 1730,
			"versionNonce": 1951935293,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1666152506546,
			"link": null,
			"locked": false,
			"text": "Anak",
			"rawText": "Anak",
			"fontSize": 36,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 32,
			"containerId": null,
			"originalText": "Anak"
		},
		{
			"type": "line",
			"version": 7758,
			"versionNonce": 1023472403,
			"isDeleted": false,
			"id": "2tHCqQiJVcdDw5-erAZr4",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 12.004601189511277,
			"x": 818.4855449709959,
			"y": -125.35409887130353,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 11.538622885462923,
			"height": 60.95907995700587,
			"seed": 1755186515,
			"groupIds": [
				"A6ll4uV1HgdNLRJw7Evtq",
				"krJet-biCzU1GzUhTw7hX",
				"YWO-opB3X9utpr8SMx_oP",
				"Yut6WcS8op42bUmZkZxMx"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1666152506546,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					11.537045160358337,
					53.97696352292202
				],
				[
					-0.001577725104584837,
					60.95907995700587
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 8147,
			"versionNonce": 1175042973,
			"isDeleted": false,
			"id": "0kKZFqQ80d3HppzZ5i28C",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.986741481222998,
			"x": 772.6152155431428,
			"y": -121.7426756038358,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 14.452758388892958,
			"height": 62.48104038979949,
			"seed": 2083384669,
			"groupIds": [
				"A6ll4uV1HgdNLRJw7Evtq",
				"krJet-biCzU1GzUhTw7hX",
				"YWO-opB3X9utpr8SMx_oP",
				"Yut6WcS8op42bUmZkZxMx"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1666152506546,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					14.319664682160473,
					62.48104038979949
				],
				[
					-0.13309370673248533,
					54.63343918654641
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 8715,
			"versionNonce": 1161238707,
			"isDeleted": false,
			"id": "bhXWFtraH4xBQGxTxEN6_",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.269319433247224,
			"x": 796.9809388368276,
			"y": -142.62991197736224,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 83.52714890218448,
			"height": 133.03626946559814,
			"seed": 402121459,
			"groupIds": [
				"yB9VlnLrA4I4t9CRQuZqV",
				"A6ll4uV1HgdNLRJw7Evtq",
				"krJet-biCzU1GzUhTw7hX",
				"YWO-opB3X9utpr8SMx_oP",
				"Yut6WcS8op42bUmZkZxMx"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1666152506546,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					44.613958784280584,
					132.23863830903306
				],
				[
					-38.9131901179039,
					131.21062826699597
				],
				[
					0.00008114047522342619,
					-0.7976311565650853
				]
			]
		},
		{
			"type": "ellipse",
			"version": 7465,
			"versionNonce": 535445501,
			"isDeleted": false,
			"id": "gpEQx8d1mVhtLCFtVOqRC",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.269319433247224,
			"x": 770.129896694923,
			"y": -172.14013199093583,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 53.17622184242456,
			"height": 51.84683658148277,
			"seed": 1847736765,
			"groupIds": [
				"yB9VlnLrA4I4t9CRQuZqV",
				"A6ll4uV1HgdNLRJw7Evtq",
				"krJet-biCzU1GzUhTw7hX",
				"YWO-opB3X9utpr8SMx_oP",
				"Yut6WcS8op42bUmZkZxMx"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1666152506546,
			"link": null,
			"locked": false
		},
		{
			"id": "oPj1GSwR",
			"type": "text",
			"x": 753.5886490217357,
			"y": -2.4670728076783632,
			"width": 92,
			"height": 46,
			"angle": 0,
			"strokeColor": "white",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"krJet-biCzU1GzUhTw7hX",
				"YWO-opB3X9utpr8SMx_oP",
				"Yut6WcS8op42bUmZkZxMx"
			],
			"strokeSharpness": "round",
			"seed": 663030931,
			"version": 2000,
			"versionNonce": 1524075091,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1666152506546,
			"link": null,
			"locked": false,
			"text": "Bapa",
			"rawText": "Bapa",
			"fontSize": 36,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 32,
			"containerId": null,
			"originalText": "Bapa"
		},
		{
			"id": "PuFdnDuk",
			"type": "text",
			"x": 1065.6940406746958,
			"y": -165.0723777264693,
			"width": 334,
			"height": 46,
			"angle": 0,
			"strokeColor": "white",
			"backgroundColor": "#000",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"Yut6WcS8op42bUmZkZxMx"
			],
			"strokeSharpness": "round",
			"seed": 1406100115,
			"version": 629,
			"versionNonce": 133904477,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1666152506546,
			"link": null,
			"locked": false,
			"text": "Let there be Light",
			"rawText": "Let there be Light",
			"fontSize": 36,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 32,
			"containerId": null,
			"originalText": "Let there be Light"
		},
		{
			"id": "RmAvbt6bvv7C5cqBGUldf",
			"type": "line",
			"x": 949.483488659893,
			"y": -126.33549707268631,
			"width": 486.85619019052956,
			"height": 160.42107833059214,
			"angle": 0,
			"strokeColor": "white",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"Yut6WcS8op42bUmZkZxMx"
			],
			"strokeSharpness": "round",
			"seed": 1490776339,
			"version": 941,
			"versionNonce": 1924712435,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1666152506547,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					45.78146073030507,
					-17.68419767680919
				],
				[
					87.93264396518329,
					-85.89474326685857
				],
				[
					472.44149189069117,
					-71.99999357524672
				],
				[
					486.85619019052956,
					66.94740696957243
				],
				[
					246.24636536065213,
					74.52633506373357
				],
				[
					101.5620028779058,
					71.99999357524669
				],
				[
					85.4593811724132,
					34.10525673314143
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": [
				1.2631707442435527,
				-3.789480108963801
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"type": "rectangle",
			"version": 1969,
			"versionNonce": 585191827,
			"isDeleted": false,
			"id": "3Y9tqw6gqI-F8KI4vu1wz",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1879.2457022031892,
			"y": -243.6924781886604,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 1098.8346066682236,
			"height": 536.60870228643,
			"seed": 1822443187,
			"groupIds": [
				"4nKoYfQTjUD9-kKxhWEaQ"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1666152506547,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 1680,
			"versionNonce": 1942258973,
			"isDeleted": false,
			"id": "migyrSX62pcZ7L3cQVyIy",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1876.4199872189326,
			"y": 122.95148604194463,
			"strokeColor": "blue",
			"backgroundColor": "blue",
			"width": 1097.7391782014265,
			"height": 210.78262992527175,
			"seed": 1634923005,
			"groupIds": [
				"4nKoYfQTjUD9-kKxhWEaQ"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1666152506547,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					73.04347826086956,
					-21.91300101902175
				],
				[
					270.260885487432,
					-4.173902428668498
				],
				[
					541.5652333135189,
					-16.695609714673935
				],
				[
					779.4783086362091,
					-44.86954398777175
				],
				[
					964.1739820397418,
					-8.34780485733694
				],
				[
					1061.2174390709918,
					-1.0434358016304373
				],
				[
					1097.7391782014265,
					-1.0434358016304373
				],
				[
					1092.521680748981,
					89.73914104959226
				],
				[
					1062.26098102072,
					137.73915166440213
				],
				[
					1000.6957211701763,
					163.82616126019013
				],
				[
					776.34789508322,
					164.86959706182063
				],
				[
					312.00001592221463,
					165.9130859375
				],
				[
					111.65216860563856,
					165.9130859375
				],
				[
					59.47825556216026,
					153.39132557744563
				],
				[
					26.086956521739125,
					126.26093325407612
				],
				[
					7.30434251868212,
					82.43482506793464
				],
				[
					3.1304135529890686,
					38.60876995584243
				],
				[
					2.086951214334192,
					-1.0434888756793725
				]
			]
		},
		{
			"type": "line",
			"version": 8492,
			"versionNonce": 2089264947,
			"isDeleted": false,
			"id": "WjFDkIlmwbGuQ7wYd12TV",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 12.004601189511277,
			"x": 2114.4857826868665,
			"y": -121.5646910408143,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 11.538622885462923,
			"height": 60.95907995700587,
			"seed": 697014909,
			"groupIds": [
				"Nu25-rIVIJGutkMD5yw77",
				"z4a1AvhUjcCsDbiMtz2kj",
				"dmggEmlMp34zzHVugsh7g"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1666152506547,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					11.537045160358337,
					53.97696352292202
				],
				[
					-0.001577725104584837,
					60.95907995700587
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 8881,
			"versionNonce": 781179261,
			"isDeleted": false,
			"id": "-hk3XjeKZ8MpwM7TkkZFV",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.986741481222998,
			"x": 2068.615453259014,
			"y": -117.95326777334662,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 14.452758388892958,
			"height": 62.48104038979949,
			"seed": 980359123,
			"groupIds": [
				"Nu25-rIVIJGutkMD5yw77",
				"z4a1AvhUjcCsDbiMtz2kj",
				"dmggEmlMp34zzHVugsh7g"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1666152506547,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					14.319664682160473,
					62.48104038979949
				],
				[
					-0.13309370673248533,
					54.63343918654641
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 9449,
			"versionNonce": 638732499,
			"isDeleted": false,
			"id": "xJxMLy6OLse0okqbp4dZA",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.269319433247224,
			"x": 2092.981176552699,
			"y": -138.84050414687306,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 83.52714890218448,
			"height": 133.03626946559814,
			"seed": 965559005,
			"groupIds": [
				"cGrwtI71exCq2yZcgqcg0",
				"Nu25-rIVIJGutkMD5yw77",
				"z4a1AvhUjcCsDbiMtz2kj",
				"dmggEmlMp34zzHVugsh7g"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1666152506547,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					44.613958784280584,
					132.23863830903306
				],
				[
					-38.9131901179039,
					131.21062826699597
				],
				[
					0.00008114047522342619,
					-0.7976311565650853
				]
			]
		},
		{
			"type": "ellipse",
			"version": 8199,
			"versionNonce": 833724893,
			"isDeleted": false,
			"id": "7vSDX75uBO6OY_y4Jg47T",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.269319433247224,
			"x": 2066.1301344107937,
			"y": -168.35072416044665,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 53.17622184242456,
			"height": 51.84683658148277,
			"seed": 1661117811,
			"groupIds": [
				"cGrwtI71exCq2yZcgqcg0",
				"Nu25-rIVIJGutkMD5yw77",
				"z4a1AvhUjcCsDbiMtz2kj",
				"dmggEmlMp34zzHVugsh7g"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1666152506547,
			"link": null,
			"locked": false
		},
		{
			"id": "JZ84togs",
			"type": "text",
			"x": 2052.115228226093,
			"y": 1.3223350228108757,
			"width": 83,
			"height": 46,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"z4a1AvhUjcCsDbiMtz2kj",
				"dmggEmlMp34zzHVugsh7g"
			],
			"strokeSharpness": "round",
			"seed": 1073405757,
			"version": 2727,
			"versionNonce": 890746483,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1666152506548,
			"link": null,
			"locked": false,
			"text": "Anak",
			"rawText": "Anak",
			"fontSize": 36,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 32,
			"containerId": null,
			"originalText": "Anak"
		},
		{
			"type": "line",
			"version": 8599,
			"versionNonce": 305880637,
			"isDeleted": false,
			"id": "qiOweqTZWR2T6dFU8PRLJ",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 12.004601189511277,
			"x": 2004.485782686867,
			"y": -120.40672563168602,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 11.538622885462923,
			"height": 60.95907995700587,
			"seed": 2031320851,
			"groupIds": [
				"3MO3Ze1g5mjbp87Jc_b2C",
				"PUyFNDss6rarKBm7B1BKG",
				"dmggEmlMp34zzHVugsh7g"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1666152506548,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					11.537045160358337,
					53.97696352292202
				],
				[
					-0.001577725104584837,
					60.95907995700587
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 8988,
			"versionNonce": 1214148627,
			"isDeleted": false,
			"id": "0eJkIz8XDjzAAU0BhxApT",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.986741481222998,
			"x": 1958.615453259014,
			"y": -116.79530236421829,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 14.452758388892958,
			"height": 62.48104038979949,
			"seed": 1932914589,
			"groupIds": [
				"3MO3Ze1g5mjbp87Jc_b2C",
				"PUyFNDss6rarKBm7B1BKG",
				"dmggEmlMp34zzHVugsh7g"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1666152506548,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					14.319664682160473,
					62.48104038979949
				],
				[
					-0.13309370673248533,
					54.63343918654641
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 9556,
			"versionNonce": 1192136349,
			"isDeleted": false,
			"id": "NV6xcxSn1HzDVRJeKe4LL",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.269319433247224,
			"x": 1982.9811765526988,
			"y": -137.68253873774472,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 83.52714890218448,
			"height": 133.03626946559814,
			"seed": 1998070963,
			"groupIds": [
				"zLsUj5jpVdtdXxNj9Jc5_",
				"3MO3Ze1g5mjbp87Jc_b2C",
				"PUyFNDss6rarKBm7B1BKG",
				"dmggEmlMp34zzHVugsh7g"
			],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1666152506548,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					44.613958784280584,
					132.23863830903306
				],
				[
					-38.9131901179039,
					131.21062826699597
				],
				[
					0.00008114047522342619,
					-0.7976311565650853
				]
			]
		},
		{
			"type": "ellipse",
			"version": 8306,
			"versionNonce": 1641870771,
			"isDeleted": false,
			"id": "yjsT3B4-uo6_u6Gif6gjp",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.269319433247224,
			"x": 1956.1301344107942,
			"y": -167.1927587513183,
			"strokeColor": "#000000",
			"backgroundColor": "#ced4da",
			"width": 53.17622184242456,
			"height": 51.84683658148277,
			"seed": 1097855997,
			"groupIds": [
				"zLsUj5jpVdtdXxNj9Jc5_",
				"3MO3Ze1g5mjbp87Jc_b2C",
				"PUyFNDss6rarKBm7B1BKG",
				"dmggEmlMp34zzHVugsh7g"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1666152506548,
			"link": null,
			"locked": false
		},
		{
			"id": "FLlw1Gj4",
			"type": "text",
			"x": 1938.3257159933637,
			"y": 5.006609796659546,
			"width": 92,
			"height": 46,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"PUyFNDss6rarKBm7B1BKG",
				"dmggEmlMp34zzHVugsh7g"
			],
			"strokeSharpness": "round",
			"seed": 1152849491,
			"version": 2843,
			"versionNonce": 1859957501,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1666152506548,
			"link": null,
			"locked": false,
			"text": "Bapa",
			"rawText": "Bapa",
			"fontSize": 36,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 32,
			"containerId": null,
			"originalText": "Bapa"
		},
		{
			"id": "D_W2ZSMdpggcxayWRaqMl",
			"type": "rectangle",
			"x": 878.7466979526558,
			"y": -74.54604266273572,
			"width": 1.263170744243439,
			"height": 1.2631386204769797,
			"angle": 0,
			"strokeColor": "white",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"strokeSharpness": "round",
			"seed": 1294022675,
			"version": 7,
			"versionNonce": 1208886461,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1666152506547,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1635,
			"versionNonce": 12175187,
			"isDeleted": true,
			"id": "iMCf2KxIdfUAjzkIcAVkP",
			"fillStyle": "solid",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1725.1401563561508,
			"y": -231.06089924129168,
			"strokeColor": "#000000",
			"backgroundColor": "#000",
			"width": 1098.8346066682236,
			"height": 536.60870228643,
			"seed": 860190781,
			"groupIds": [
				"ESQQ0zKay1JQ3BIpEZsvW"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1666152506548,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 1371,
			"versionNonce": 1445415773,
			"isDeleted": true,
			"id": "BwQhhWH39_GSChMLU54DB",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1724.8407828603813,
			"y": 139.37251297451076,
			"strokeColor": "blue",
			"backgroundColor": "blue",
			"width": 1097.7391782014265,
			"height": 210.78262992527175,
			"seed": 672855571,
			"groupIds": [
				"ESQQ0zKay1JQ3BIpEZsvW"
			],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1666152506549,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					73.04347826086956,
					-21.91300101902175
				],
				[
					270.260885487432,
					-4.173902428668498
				],
				[
					541.5652333135189,
					-16.695609714673935
				],
				[
					779.4783086362091,
					-44.86954398777175
				],
				[
					964.1739820397418,
					-8.34780485733694
				],
				[
					1061.2174390709918,
					-1.0434358016304373
				],
				[
					1097.7391782014265,
					-1.0434358016304373
				],
				[
					1092.521680748981,
					89.73914104959226
				],
				[
					1062.26098102072,
					137.73915166440213
				],
				[
					1000.6957211701763,
					163.82616126019013
				],
				[
					776.34789508322,
					164.86959706182063
				],
				[
					312.00001592221463,
					165.9130859375
				],
				[
					111.65216860563856,
					165.9130859375
				],
				[
					59.47825556216026,
					153.39132557744563
				],
				[
					26.086956521739125,
					126.26093325407612
				],
				[
					7.30434251868212,
					82.43482506793464
				],
				[
					3.1304135529890686,
					38.60876995584243
				],
				[
					2.086951214334192,
					-1.0434888756793725
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 4,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 36,
		"currentItemTextAlign": "left",
		"currentItemStrokeSharpness": "round",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"currentItemLinearStrokeSharpness": "round",
		"gridSize": null,
		"colorPalette": {}
	},
	"files": {}
}
```
%%